from otter.test_files import test_case

OK_FORMAT = False

name = "fraction_class"
points = None

@test_case(points=None, hidden=False)
def test_string_representation(Fraction):
    result = str(Fraction(1, 2))
    expected = '1/2'
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_string_representation_reduced_whole(Fraction):
    result = str(Fraction(75, 15))
    expected = '5'
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_string_representation_zero(Fraction):
    result = str(Fraction(0, 23))
    expected = '0'
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_string_representation_reduced_fraction(Fraction):
    result = str(Fraction(25, 50))
    expected = '1/2'
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_string_representation_negative_input_positive_result(Fraction):
    result = str(Fraction(-13, -13))
    expected = '1'
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_string_representation_negative_input_negative_result(Fraction):
    result = str(Fraction(-14, 49))
    expected = '-2/7'
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_string_representation_more(Fraction):
    result = str(Fraction(6, -9))
    expected = '-2/3'
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_string_representation_more_again(Fraction):
    result = str(Fraction(-26, -65))
    expected = '2/5'
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_addition(Fraction):
    first = Fraction(1,2)
    second = Fraction(2,5)
    first_str = str(first)
    second_str = str(second)
    expected = '9/10'
    result = str(first + second)
    if str(first) != first_str or str(second) != second_str:
        raise ValueError('Do not modify the fractions when adding, create a new one instead')
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
    
@test_case(points=None, hidden=False)
def test_addition_negatives(Fraction):
    first = Fraction(-2,7)
    second = Fraction(2,7)
    first_str = str(first)
    second_str = str(second)
    expected = '0'
    result = str(first + second)
    if str(first) != first_str or str(second) != second_str:
        raise ValueError('Do not modify the fractions when adding, create a new one instead')
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_subtraction(Fraction):
    first = Fraction(2,7)
    second = Fraction(1,7)
    first_str = str(first)
    second_str = str(second)
    expected = '1/7'
    result = str(first - second)
    if str(first) != first_str or str(second) != second_str:
        raise ValueError('Do not modify the fractions when adding, create a new one instead')
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_subtraction_negative(Fraction):
    first = Fraction(2,7)
    second = Fraction(-1,7)
    first_str = str(first)
    second_str = str(second)
    expected = '3/7'
    result = str(first - second)
    if str(first) != first_str or str(second) != second_str:
        raise ValueError('Do not modify the fractions when adding, create a new one instead')
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_multiplication(Fraction):
    first = Fraction(1,2)
    second = Fraction(-2,3)
    expected = '-1/3'
    first_str = str(first)
    second_str = str(second)
    result = str(first * second)
    if str(first) != first_str or str(second) != second_str:
        raise ValueError('Do not modify the fractions when adding, create a new one instead')
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_multiplication_2(Fraction):
    first = Fraction(-2,3)
    second = Fraction(2,5)
    expected = '-4/15'
    first_str = str(first)
    second_str = str(second)
    result = str(first * second)
    if str(first) != first_str or str(second) != second_str:
        raise ValueError('Do not modify the fractions when adding, create a new one instead')
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_division(Fraction):
    first = Fraction(1,2)
    second = Fraction(-2,3)
    expected = '-3/4'
    first_str = str(first)
    second_str = str(second)
    result = str(first / second)
    if str(first) != first_str or str(second) != second_str:
        raise ValueError('Do not modify the fractions when adding, create a new one instead')
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_division_2(Fraction):
    first = Fraction(-2,3)
    second = Fraction(2,5)
    expected = '-5/3'
    first_str = str(first)
    second_str = str(second)
    result = str(first / second)
    if str(first) != first_str or str(second) != second_str:
        raise ValueError('Do not modify the fractions when adding, create a new one instead')
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_lt(Fraction):
    if not Fraction(-2, 7) < Fraction(1,2):
        raise ValueError('-2/7 should be less than 1/2')
@test_case(points=None, hidden=False)
def test_gt(Fraction):
    if not Fraction(1, 2) > Fraction(-2,7):
        raise ValueError('1/2 should be greater than -2/7')
@test_case(points=None, hidden=False)
def test_ne(Fraction):
    if not Fraction(1, 2) != Fraction(-2,7):
        raise ValueError('1/2 should not be equal to -2/7')
@test_case(points=None, hidden=False)
def test_eq(Fraction):
    if not Fraction(-2, 7) == Fraction(-2,7):
        raise ValueError('-2/7 should be equal to -2/7')
@test_case(points=None, hidden=False)
def test_big(Fraction):
    result = str(Fraction(1,3) * Fraction(1000000, 1) - (Fraction(1000000, 1)/Fraction(3,1)))
    expected = '0'
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
@test_case(points=None, hidden=False)
def test_repr(Fraction):
    result = repr(Fraction(1,3))
    expected = "Fraction(1, 3)"
    if result != expected:
        raise ValueError(f'Expected: "{expected}" but got: "{result}"')
