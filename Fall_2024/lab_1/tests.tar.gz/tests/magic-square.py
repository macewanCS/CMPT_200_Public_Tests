from otter.test_files import test_case

OK_FORMAT = False

name = "magic-square"
points = None

@test_case(points=None, hidden=False)
def test_1(test_magic_square, magic_square):
    expected = '''-----Magic Square Checker-----

Numbers do not make a square of size 3!'''
    test_magic_square('14 6, 78 2      5', expected)
@test_case(points=None, hidden=False)
def test_2(test_magic_square, magic_square):
    expected = '''-----Magic Square Checker-----

Numbers do not make a square of size 3!'''
    test_magic_square('14 6, 78 x      5', expected)
@test_case(points=None, hidden=False)
def test_3(test_magic_square, magic_square):
    expected = '''-----Magic Square Checker-----

2 7 6
9 5 1
4 3 8
The square is magical!'''
    test_magic_square('276,     9 5 1 4-3-8', expected)
@test_case(points=None, hidden=False)
def test_4(test_magic_square, magic_square):
    expected = '''-----Magic Square Checker-----

2 7 6
9 5 1
4 3 8
The square is magical!'''
    test_magic_square('276, 9 x 1 4 3 8', expected)
@test_case(points=None, hidden=False)
def test_5(test_magic_square, magic_square):
    expected = '''-----Magic Square Checker-----

2 7 6
9 x 1
4 3 5
Sorry, the square isn't magical.'''
    test_magic_square('276, 9 x 1 4 3 5', expected)
