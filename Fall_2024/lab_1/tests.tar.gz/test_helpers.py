import io
from contextlib import redirect_stdout
from unittest.mock import patch
import difflib
from magic_square import magic_square


def compare_strings(a, b):
    g = "The test expected:\n"
    g += b + "\n"
    g += "\n"
    g += "Your output was:\n"
    g += a + "\n"
    g += "\n"
    g += "This is a list of changes you need to make to comply with the test from your output\n"

    for i, s in enumerate(difflib.ndiff(a, b)):
        if s[0] == " ":
            continue
        elif s[0] == "-":
            g += f'Delete "{s[-1]}" from position {i}'
        elif s[0] == "+":
            g += f'Add "{s[-1]}" to position {i}'
        g += "\n"
    return g


def test_magic_square(input_values, expected):
    val = ""
    with redirect_stdout(io.StringIO()) as f, patch(
        "builtins.input", side_effect=[input_values]
    ):
        magic_square()
        val = f.getvalue().strip()
    if expected != val:
        failure_message = compare_strings(val, expected)
        raise ValueError(failure_message)
