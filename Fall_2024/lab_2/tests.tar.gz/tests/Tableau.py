from otter.test_files import test_case

OK_FORMAT = False

name = "Tableau"
points = None

@test_case(points=None, hidden=False)
def test_tableau_1(game_of_cards, test_helpers):
    t = game_of_cards.Tableau()
    t_cards = test_helpers.deck_str_to_cards(t._deck)
    assert len(str(t)) == 0, "Make sure when you deal the tableau there are no piles"
    for i in range(1, 10):
        t.add_pile()
        expected = test_helpers.tableau_str_from_cards(t_cards, i)
        got = str(t)
        assert got == expected, test_helpers.compare_strings(got, expected)
@test_case(points=None, hidden=False)
def test_tableau_2(game_of_cards, test_helpers):
    t = game_of_cards.Tableau()
    t_cards = test_helpers.deck_str_to_cards(t._deck)
    for i in range(1, 10):
        t.add_pile()
        data = test_helpers.get_tableau_data(t_cards , i)
        expected = data['min']
        got = t.find_lowest_top()
        assert expected == str(got[1]), f"expected min value of: '{expected}' but got {str(got[1])}"
        assert data['tops'][got[0]-1] == data['min'], 'Index of min returned is incorrect'
@test_case(points=None, hidden=False)
def test_tableau_3(game_of_cards, test_helpers):
    t = game_of_cards.Tableau()
    t_cards = test_helpers.deck_str_to_cards(t._deck)
    for i in range(1, 10):
        t.add_pile()
        data = test_helpers.get_tableau_data(t_cards , i)
        expected = data['max']
        got = t.find_highest_top()
        assert expected == str(got[1]), f"expected max value of: '{expected}' but got {str(got[1])}"
        assert data['tops'][got[0]-1] == data['max'], 'Index of max returned is incorrect'
@test_case(points=None, hidden=False)
def test_tableau_4(game_of_cards, test_helpers):
    for _ in range(5):
        t = game_of_cards.Tableau()
        t_cards = test_helpers.deck_str_to_cards(t._deck)
        for i in range(0, 10):
    
            data = test_helpers.get_tableau_data(t_cards , i)
            expected = data['asc']
            got = t.is_ascending()
            assert expected == got, f"expected min value of: '{expected}' but got {got}"
            expected = data['dsc']
            got = t.is_descending()
            assert expected == got, f"expected min value of: '{expected}' but got {got}"
            t.add_pile()
@test_case(points=None, hidden=False)
def test_tableau_5(game_of_cards, test_helpers):
    for _ in range(5):
        t = game_of_cards.Tableau()
        t_cards = test_helpers.deck_str_to_cards(t._deck)
        for i in range(0, 10):
            data = test_helpers.get_tableau_data(t_cards , i)
            expected = data['tops']
            got = [str(s) for s in t.get_tops()]
            assert expected == got, f"expected min value of: '{expected}' but got {got}"
            t.add_pile()
