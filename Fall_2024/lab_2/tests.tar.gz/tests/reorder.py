from otter.test_files import test_case

OK_FORMAT = False

name = "reorder"
points = None

@test_case(points=None, hidden=False)
def test_reorder_1(recursion):
    assert recursion.reorder([0,0,1,0,0,1,0,0,0,1,1,1,1,1]) == [0,0,0,0,0,0,0,1,1,1,1,1,1,1] ,'expected reorder([0,0,1,0,0,1,0,0,0,1,1,1,1,1]) to be [0,0,0,0,0,0,0,1,1,1,1,1,1,1]'
test_reorder_1(recursion)
@test_case(points=None, hidden=False)
def test_reorder_2(recursion):
    initial = [0,0,1,0,0,1,0,0,0,1,1,1,1,1]
    expected = [0,0,0,0,0,0,0,1,1,1,1,1,1,1]
    initial_copy = initial.copy()
    assert recursion.reorder(initial) == expected ,f'expected {expected}'
    assert initial == initial_copy, 'origial list modified by reorder function'
test_reorder_2(recursion)
@test_case(points=None, hidden=False)
def test_reorder_3(recursion):
    initial = [0,0,0,1,0,0,0,1,0,0,0,1,1,1,1,1,0]
    expected = [0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1]
    initial_copy = initial.copy()
    assert recursion.reorder(initial) == expected ,f'expected {expected} but got {recursion.reorder(initial)}'
    assert initial == initial_copy, 'origial list modified by reorder function'
test_reorder_3(recursion)
@test_case(points=None, hidden=False)
def test_reorder_4(recursion):
    initial = [1,0,0,0,1,0,0,0,1,0,0,0,1,1,1,1,1,0]
    expected = [0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1]
    initial_copy = initial.copy()
    assert recursion.reorder(initial) == expected ,f'expected {expected} but got {recursion.reorder(initial)}'
    assert initial == initial_copy, 'origial list modified by reorder function'
test_reorder_4(recursion)
