from otter.test_files import test_case

OK_FORMAT = False

name = "Card"
points = None

@test_case(points=None, hidden=False)
def test_1(game_of_cards):
    c1 = game_of_cards.Card("2","C")
    expected = "2C"
    got = str(c1)
    assert got == expected, f"Expected: '{expected}', but got '{got}'"
@test_case(points=None, hidden=False)
def test_2(game_of_cards):
    c1 = game_of_cards.Card("2","c")
    expected = "2C"
    got = str(c1)
    assert got == expected, f"Expected: '{expected}', but got '{got}' (watch your casing)"
@test_case(points=None, hidden=False)
def test_3(game_of_cards):
    c1 = game_of_cards.Card("T","D")
    expected = "TD"
    got = str(c1)
    assert got == expected, f"Expected: '{expected}', but got '{got}' (10 should be T)"
@test_case(points=None, hidden=False)
def test_4(game_of_cards):
    c1 = game_of_cards.Card("T","D")
    expected = "Card(rank='T', suit='D')"
    got = repr(c1)
    assert got == expected, f"Expected: '{expected}', but got '{got}'"
@test_case(points=None, hidden=False)
def test_5(game_of_cards):
    c1 = game_of_cards.Card("2", "C")
    c2 = game_of_cards.Card("2", "C")
    assert c1 == c2, f"Two cards that are the same are not equal. Your __eq__ function is not working."
@test_case(points=None, hidden=False)
def test_6(game_of_cards):
    c1 = game_of_cards.Card("2", "C")
    c2 = game_of_cards.Card("3", "C")
    assert c1 != c2, f"Two cards that are not the same are not not equal. (yep that is hard to write and understand, basically __ne__ is failing"
@test_case(points=None, hidden=False)
def test_7(game_of_cards):
    c1 = game_of_cards.Card("4", "C")
    c2 = game_of_cards.Card("3", "H")
    assert c2 < c1, f"Your less than (__lt__) operation is not working"
@test_case(points=None, hidden=False)
def test_8(game_of_cards):
    c1 = game_of_cards.Card("4", "C")
    c2 = game_of_cards.Card("3", "H")
    assert c2 <= c1, f"Your less than or equal to (__le__) operation is not working"
@test_case(points=None, hidden=False)
def test_9(game_of_cards):
    c1 = game_of_cards.Card("3", "S")
    c2 = game_of_cards.Card("3", "S")
    assert c2 <= c1, f"Your less than or equal to (__le__) operation is not working"
@test_case(points=None, hidden=False)
def test_10(game_of_cards):
    c1 = game_of_cards.Card("K", "H")
    c2 = game_of_cards.Card("K", "H")
    assert c2 >= c1, f"Your greater than or equal to (__ge__) operation is not working"
@test_case(points=None, hidden=False)
def test_11(game_of_cards):
    c1 = game_of_cards.Card("K", "H")
    c2 = game_of_cards.Card("Q", "S")
    assert c1 >= c2, f"Your greater than or equal to (__ge__) operation is not working"
@test_case(points=None, hidden=False)
def test_12(game_of_cards):
    c1 = game_of_cards.Card("K", "H")
    c2 = game_of_cards.Card("Q", "S")
    assert c1 > c2, f"Your greater than to (__ge__) operation is not working"
@test_case(points=None, hidden=False)
def test_13(game_of_cards):
    c1 = game_of_cards.Card("T", "H")
    c2 = game_of_cards.Card("T", "S")
    assert c2 > c1, f"Your greater than to (__ge__) operation is not working for suits (Spades > Hearts)"
@test_case(points=None, hidden=False)
def test_14(game_of_cards):
    c1 = game_of_cards.Card("5", "C")
    c2 = game_of_cards.Card("5", "D")
    assert c1 < c2, f"Your greater than to (__lt__) operation is not working for suits (Clubs < Diamonds)"
