import difflib
from random import seed
from contextlib import redirect_stdout
import io

ENDC = "\033[0m"
ERRORC = "\033[1m\033[91m"


def compare_strings(got, expected):
    if got == expected:
        return
    got = repr(got)
    expected = repr(expected)
    message = f"""The test expected:
{expected}

Your output was:
{got}
p
This is a list of changes you need to make to comply with the test from your output
"""
    results = difflib.ndiff(got, expected)
    result = ""
    for i, s in enumerate(results):
        if s[0] == " ":
            result += s[-1]
            continue

        # there is an error
        result += ERRORC
        if s[0] == "-":
            message += f"Delete {s[-1]} from position {i}\n"
        elif s[0] == "+":
            message += f"Add {s[-1]} to position {i}\n"
        result += s[-1].replace(" ", "_")
        result += ENDC

    print(message)

    print(
        "Look at the "
        + ERRORC
        + "red "
        + ENDC
        + "areas in the summary below for more of a hint (Note that spaces that are missing are replaced with UNDERSCORES '_' so that they may be highlighted):"
    )
    print()
    print(result)

    assert got == expected, "Sorry your output is not correct"


def methods_check(inbound_object, expected_methods={}):
    missing_methods = set()
    for method in expected_methods:
        if method not in dir(inbound_object):
            missing_methods.add(method)
    if len(missing_methods) > 0:
        raise AssertionError(
            f"The following methods are not yet implemented: {', '.join(missing_methods)}"
        )


def test_simulation(sim, seed_value, expected):
    seed(seed_value)
    with redirect_stdout(io.StringIO()) as f:
        sim()
        val = f.getvalue().strip()
    compare_strings(val, expected)


def find_good_seeds(sim):
    shortest = []
    longest = []
    for x in range(10000):
        seed(x)
        with redirect_stdout(io.StringIO()) as f:
            sim()
            length = len(f.getvalue().strip())
            if len(shortest) < 5:
                shortest.append((length, x))
                longest.append((length, x))
                shortest.sort()
                longest.sort(reverse=True)
                continue
            if length < shortest[-1][0]:
                shortest[-1] = (length, x)
                shortest.sort()
            if length > longest[-1][0]:
                longest[-1] = (length, x)
                longest.sort(reverse=True)
    return shortest, longest
