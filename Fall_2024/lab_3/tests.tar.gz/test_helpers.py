import io
from contextlib import redirect_stdout
from unittest.mock import patch
import difflib


def compare_strings(got, expected):
    g = f"""The test expected:
{repr(expected)}

Your output was:
{repr(got)}

This is a list of changes you need to make to comply with the test from your output
"""

    for i, s in enumerate(difflib.ndiff(got, expected)):
        if s[0] == " ":
            continue
        elif s[0] == "-":
            g += f'Delete "{s[-1]}" from position {i}'
        elif s[0] == "+":
            g += f'Add "{s[-1]}" to position {i}'
        g += "\n"
    return g


def deck_str_to_cards(d):
    return str(d).replace("\n", ", ").split(", ")


def tableau_str_from_cards(cards, num_piles):
    cards = cards.copy()
    if num_piles < 1:
        return ""
    pile_count = 0
    piles = []
    while pile_count < num_piles:
        piles.append([])
        pile_count += 1
        for _ in range(pile_count):
            piles[pile_count - 1].append(cards.pop())
        piles[pile_count - 1].extend([""] * (num_piles - pile_count))
    return "\n".join([("\t".join(f"{c}" for c in x).rstrip()) for x in zip(*piles)])


def patch(c):
    for old, new in (("T", "B"), ("J", "C"), ("Q", "D"), ("K", "E"), ("A", "F")):
        c = c.replace(old, new)
    return c


def gt(a, b):
    if a[0] == b[0]:
        return a[1] > b[1]
    return patch(a)[0] > patch(b)[0]


def is_ascending(tops):
    for i in range(1, len(tops)):
        if gt(tops[i - 1], tops[i]):
            return False
    return True


def is_descending(tops):
    for i in range(1, len(tops)):
        if gt(tops[i], tops[i - 1]):
            return False
    return True


def get_min(tops):
    mn = None
    if len(tops):
        mn = tops[0]
    for i in range(1, len(tops)):
        if not gt(tops[i], mn):
            mn = tops[i]
    return mn


def get_max(tops):
    mx = None
    if len(tops):
        mx = tops[0]
    for i in range(1, len(tops)):
        if gt(tops[i], mx):
            mx = tops[i]
    return mx


def get_tableau_data(cards, num_piles):
    cards = cards[::-1]
    tops = []
    i = 0
    next_card = 1
    piles = 0
    while piles < num_piles:
        next_card += 1
        tops.append(cards[i])
        i += next_card
        piles += 1
    return {
        "cards": cards[::-1],
        "tops": tops,
        "asc": is_ascending(tops),
        "dsc": is_descending(tops),
        "max": get_max(tops),
        "min": get_min(tops),
    }
