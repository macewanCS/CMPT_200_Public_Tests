import difflib
from random import seed
from contextlib import redirect_stdout
import io

ENDC = "\033[0m"
ERRORC = "\033[1m\033[91m"


def compare_strings(got, expected):
    if got == expected:
        return
    got = repr(got)
    expected = repr(expected)
    message = f"""The test expected:
{expected}

Your output was:
{got}

This is a list of changes you need to make to comply with the test from your output:
"""
    results = difflib.ndiff(got, expected)
    result = ""
    for i, s in enumerate(results):
        if s[0] == " ":
            result += s[-1]
            continue

        # there is an error
        result += ERRORC
        if s[0] == "-":
            message += f"Delete {s[-1]} from position {i}\n"
        elif s[0] == "+":
            message += f"Add {s[-1]} to position {i}\n"
        result += s[-1].replace(" ", "_")
        result += ENDC

    print(message)

    print(
        "Look at the "
        + ERRORC
        + "red "
        + ENDC
        + "areas in the summary below for more of a hint (Note that spaces that are missing are replaced with UNDERSCORES '_' so that they may be highlighted):"
    )
    print()
    print(result)

    assert got == expected, "Sorry your output is not correct"


def methods_check(inbound_object, expected_methods={}):
    missing_methods = set()
    for method in expected_methods:
        if method not in dir(inbound_object):
            missing_methods.add(method)
    if len(missing_methods) > 0:
        raise AssertionError(
            f"The following methods are not yet implemented: {', '.join(missing_methods)}"
        )


def test_simulation(sim, seed_value, expected):
    seed(seed_value)
    with redirect_stdout(io.StringIO()) as f:
        sim()
        val = f.getvalue().strip()
    for i, e in enumerate(expected):
        e = e.strip()
        if e not in val:
            print(
                f"Test could not find the {i+1} output of {len(expected)} total outputs for this simulation."
            )
            print("The test was looking for the following summary in your output:")
            print(e)
            print("The closest I could find is:")
            match = difflib.get_close_matches(
                e, [val[i : i + len(e)] for i in range(len(val) - len(e) + 1)], n=1
            )[0]
            compare_strings(match.strip(), e.strip())
