from otter.test_files import test_case

OK_FORMAT = False

name = "is_balanced"
points = None

@test_case(points=None, hidden=False)
def test_balanced_1(recursion):
    assert not recursion.is_balanced('0100110'), '0100110 should not be balanced'
@test_case(points=None, hidden=False)
def test_balanced_2(recursion):
    assert recursion.is_balanced('010110'), '010110 should be balanced'
@test_case(points=None, hidden=False)
def test_balanced_3(recursion):
    assert not recursion.is_balanced('010010'), '010010 should not be balanced'
@test_case(points=None, hidden=False)
def test_balanced_4(recursion):
    assert recursion.is_balanced(('0'*100)+('1'*100)), 'this 200 digit thing should be balanced'
@test_case(points=None, hidden=False)
def test_balanced_5(recursion):
    assert not recursion.is_balanced(('0'*100)+('1'*101)), 'this 201 digit thing should not be balanced'
