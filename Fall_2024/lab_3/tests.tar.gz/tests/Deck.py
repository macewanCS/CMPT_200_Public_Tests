from otter.test_files import test_case

OK_FORMAT = False

name = "Deck"
points = None

@test_case(points=None, hidden=False)
def test_deck_1(game_of_cards):
    d = game_of_cards.Deck()
    #print(repr(str(d)))
    assert isinstance(d, game_of_cards.Deck), "Deck init not working as expected"
    assert len(d) == 52, "Deck does not contain 52 cards (at least according to your len function)"
@test_case(points=None, hidden=False)
def test_deck_2(game_of_cards, test_helpers):
    d = game_of_cards.Deck()
    expected = '2C, 3C, 4C, 5C, 6C\n7C, 8C, 9C, TC, JC\nQC, KC, AC, 2D, 3D\n4D, 5D, 6D, 7D, 8D\n9D, TD, JD, QD, KD\nAD, 2H, 3H, 4H, 5H\n6H, 7H, 8H, 9H, TH\nJH, QH, KH, AH, 2S\n3S, 4S, 5S, 6S, 7S\n8S, 9S, TS, JS, QS\nKS, AS'
    got = str(d)
    assert got == expected, test_helpers.compare_strings(got, expected)
@test_case(points=None, hidden=False)
def test_deck_3(game_of_cards, test_helpers):
    d = game_of_cards.Deck()
    expected_list = test_helpers.deck_str_to_cards(d)
    for i in range(52, 0, -1):
        assert len(d) == i, "Draw not removing card from deck properly"
        c = d.draw()
        assert str(c) == expected_list.pop(), "make sure you are removing from the top of the deck"
@test_case(points=None, hidden=False)
def test_deck_4(game_of_cards, test_helpers):
    d = game_of_cards.Deck()
    original_string = test_helpers.deck_str_to_cards(d)
    d.shuffle()
    new_string = test_helpers.deck_str_to_cards(d)
    assert new_string != original_string, "shuffle did not change deck"
    assert set(original_string) == set(new_string), "suffled deck does not contain the same cards"
