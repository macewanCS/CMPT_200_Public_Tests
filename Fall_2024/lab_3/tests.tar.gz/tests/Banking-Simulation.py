from otter.test_files import test_case

OK_FORMAT = False

name = "Banking-Simulation"
points = None

@test_case(points=1, hidden=False, 
    success_message="Shortest case correct, no status calls, only final statistics, 1 teller, 1 customer, 1 service period.")
def banking_simulator_simplest(banking, test_helpers):
    def gene():
        yield "call", 1
        yield "add", "1"
        yield "service", 1
        yield "quit", None

    banking.generate_jobs = gene
    test_helpers.test_simulation(banking.banking_simulation, None, ['*** Final Statistics ***\nTeller: 0 Total service time: 1 Percentage idle: 0.00%\nCustomers in queue:  0 <<>>'])
#banking_simulator_simplest(banking, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Slightly more complicated test passed with 4 tellers, 3 customers, 5 service and some idle time.")
def banking_simulator_4_3_5(banking, test_helpers):
    def gene():
        yield "call", 4
        yield "add", "3 4 5"
        yield "service", 5
        yield "quit", None

    banking.generate_jobs = gene
    test_helpers.test_simulation(banking.banking_simulation, 6915, ['*** Final Statistics ***\nTeller: 0 Total service time: 3 Percentage idle: 40.00%\nTeller: 1 Total service time: 4 Percentage idle: 20.00%\nTeller: 2 Total service time: 5 Percentage idle: 0.00%\nTeller: 3 Total service time: 0 Percentage idle: 100.00%\nCustomers in queue:  0 <<>>'])
#banking_simulator_4_3_5(banking, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Slightly more complicated test passed with 4 tellers, 3 customers and some idle time.")
def banking_simulator_4_3_5_More(banking, test_helpers):
    def gene():
        yield "call", 4 # Create 4 tellers
        yield "add", "3 4 5" # 3 customers with jobs of 3, 4, and 5 respectively get in line
        yield "service", 3 
        yield "status", None
        yield "add", "10 2 4 6 8" # Queue should be <<1, 2, 10, 2, 4, 6, 8>>
        yield "service", 4 
        yield "status", None
        yield "service", 7
        yield "quit", None

    banking.generate_jobs = gene
    test_helpers.test_simulation(banking.banking_simulation, 6915, ['Teller: 0 Total service time: 3 Percentage idle: 0.00%\nTeller: 1 Total service time: 3 Percentage idle: 0.00%\nTeller: 2 Total service time: 3 Percentage idle: 0.00%\nTeller: 3 Total service time: 0 Percentage idle: 100.00%\nCustomers in queue:  2 <<1, 2>>',
                                                                    'Teller: 0 Total service time: 4 Percentage idle: 42.86%\nTeller: 1 Total service time: 5 Percentage idle: 28.57%\nTeller: 2 Total service time: 7 Percentage idle: 0.00%\nTeller: 3 Total service time: 2 Percentage idle: 71.43%\nCustomers in queue:  4 <<4, 6, 8, 6>>',
                                                                    '*** Final Statistics ***\nTeller: 0 Total service time: 8 Percentage idle: 42.86%\nTeller: 1 Total service time: 11 Percentage idle: 21.43%\nTeller: 2 Total service time: 14 Percentage idle: 0.00%\nTeller: 3 Total service time: 8 Percentage idle: 42.86%\nCustomers in queue:  1 <<1>>'])
#banking_simulator_4_3_5_More(banking, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Another short case correct")
def banking_simulator_short_random(banking, test_helpers):
    def gene():
        yield "call", 3
        yield "add", "15 5 5"
        yield "add", "3 8 6"
        yield "service", 4
        yield "service", 5
        yield "service", 5
        yield "add", "9 15 14 14 10 15"
        yield "add", "7 4 13"
        yield "service", 4
        yield "add", "10 14"
        yield "service", 1
        yield "service", 2
        yield "add", "13 13 10 10"
        yield "quit", None
    banking.generate_jobs = gene
    test_helpers.test_simulation(banking.banking_simulation, 3688, ['*** Final Statistics ***\nTeller: 0 Total service time: 18 Percentage idle: 14.29%\nTeller: 1 Total service time: 14 Percentage idle: 33.33%\nTeller: 2 Total service time: 17 Percentage idle: 19.05%\nCustomers in queue:  16 <<7, 4, 13, 2, 10, 14, 8, 14, 13, 12, 8, 13, 13, 13, 10, 10>>'])
#banking_simulator_short_random(banking, test_helpers)    
@test_case(points=1, hidden=False, 
    success_message="Medium case correct")
def banking_simulator_long(banking, test_helpers):
    def gene():
        yield 'call', 4
        yield 'add', '14'
        yield 'add', '5 14'
        yield 'add', '14 11 4 12 9 3'
        yield 'add', '6'
        yield 'add', '12 3 11 6 14'
        yield 'status', None
        yield 'service', 2
        yield 'service', 5
        yield 'service', 1
        yield 'add', '9 8 7 5 6 15'
        yield 'service', 1
        yield 'add', '4 8 8 12'
        yield 'service', 1
        yield 'status', None
        yield 'service', 5
        yield 'add', '4 11 7 13'
        yield 'status', None
        yield 'service', 5
        yield 'quit', None
    banking.generate_jobs = gene
    test_helpers.test_simulation(banking.banking_simulation, 42, ['Teller: 0 Total service time: 0 Teller: 1 Total service time: 0 Teller: 2 Total service time: 0 Teller: 3 Total service time: 0 Customers in queue:  15 <<14, 5, 14, 14, 11, 4, 12, 9, 3, 6, 12, 3, 11, 6, 14>>','Teller: 0 Total service time: 10 Percentage idle: 0.00%\nTeller: 1 Total service time: 9 Percentage idle: 10.00%\nTeller: 2 Total service time: 10 Percentage idle: 0.00%\nTeller: 3 Total service time: 10 Percentage idle: 0.00%\nCustomers in queue:  24 <<7, 4, 2, 5, 11, 2, 9, 8, 7, 5, 6, 15, 10, 5, 13, 11, 4, 8, 8, 12, 2, 11, 11, 5>>','*** Final Statistics ***\nTeller: 0 Total service time: 20 Percentage idle: 0.00%\nTeller: 1 Total service time: 15 Percentage idle: 25.00%\nTeller: 2 Total service time: 17 Percentage idle: 15.00%\nTeller: 3 Total service time: 20 Percentage idle: 0.00%\nCustomers in queue:  24 <<7, 5, 6, 15, 10, 5, 13, 11, 4, 8, 8, 12, 2, 11, 11, 5, 2, 4, 11, 7, 13, 6, 4, 3>>'])
#banking_simulator_long(banking, test_helpers)    
