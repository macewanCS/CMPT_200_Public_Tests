from otter.test_files import test_case

OK_FORMAT = False

name = "Queue"
points = None

@test_case(points=1, hidden=False, 
    success_message="Queue methods seem correctly defined -- They actually all exist")
def test_1(banking_queue):
    q = banking_queue.Queue()
    for method in {'peek', '__init__', '__len__', 'enqueue', 'dequeue','is_empty', '__str__'}:
        assert method in dir(q), f"method {method} is not defined, but is required"
    assert q.is_empty(), 'queue does not start empty!' 
test_1(banking_queue)
@test_case(points=None, hidden=False)
def test_2(test_helpers, Queue):
    q = Queue()
    test_helpers.compare_strings(str(q), '<<>>')
    q.enqueue(1)
    test_helpers.compare_strings(str(q), '<<1>>')
    q.enqueue(2)
    test_helpers.compare_strings(str(q), '<<1, 2>>')
    def test_deq(q, expected):
        before = str(q)
        assert q.peek() == expected, f'should have gotten {expected} from peek, here is what is in your queue: {q}' 
        assert q.dequeue() == expected, f'should have gotten {expected} from dequeue, here is what was in your queue before dequeue: {before}, and now: {q}'        
    test_deq(q, 1)
    test_deq(q, 2)
test_2(test_helpers, Queue)
