from otter.test_files import test_case

OK_FORMAT = False

name = "Queue"
points = None

@test_case(points=1, hidden=False, 
    success_message="Queue methods seem correctly defined -- They actually all exist")
def test_1(banking_queue, test_helpers):
    q = banking_queue.Queue()
    assert q is not None, 'Queue not correctly defined or not currently imported'
    test_helpers.methods_check(q, {'peek', 
                                   '__init__', 
                                   '__len__', 
                                   'enqueue', 
                                   'dequeue',
                                   'is_empty', 
                                   '__str__'})
#test_1(banking_queue, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Queue starts empty, has a numpy array, and the numpy array is no greater than 10 items long")
def test_2(banking_queue, test_helpers):
    q = banking_queue.Queue()
    import numpy
    assert q.is_empty(), 'queue does not start empty!' 
    for i in dir(q):
        result = eval(f"isinstance(q.{i}, numpy.ndarray)")
        if result:
            global Numpy_Loc
            Numpy_Loc = i
            break
    else:        
        raise AssertionError("You need to declare your array using numpy.ndarray")
    arr_size = eval(f"q.{Numpy_Loc}.size")
    assert arr_size <=10, "You must start with an initial capacity of 10 or less, yours is set to " + str(arr_size)
        
#test_2(banking_queue, test_helpers)
@test_case(points=4, hidden=False, 
    success_message="Enqueue and dequeue work in the most trivial sense, and your string output appears to be correct.")
def test_3(banking_queue, test_helpers):
    q = banking_queue.Queue()
    test_helpers.compare_strings(str(q), '<<>>')
    q.enqueue(1)
    test_helpers.compare_strings(str(q), '<<1>>')
    q.enqueue(2)
    test_helpers.compare_strings(str(q), '<<1, 2>>')
    def test_deq(q, expected):
        before = str(q)
        assert q.peek() == expected, f'should have gotten {expected} from peek, here is what is in your queue: {q}' 
        assert q.dequeue() == expected, f'should have gotten {expected} from dequeue, here is what was in your queue before dequeue: {before}, and now: {q}'        
    test_deq(q, 1)
    test_deq(q, 2)
#test_3(banking_queue, test_helpers)
