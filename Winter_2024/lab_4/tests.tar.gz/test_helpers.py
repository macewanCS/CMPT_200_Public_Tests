import difflib
from random import seed
from contextlib import redirect_stdout
import sys

ENDC = "\033[0m"
DELETEC = "\033[1m\033[91m"
ADDC = "\033[1m\033[92m"


def compare_strings(expected, got):
    if got == expected:
        return
    got = repr(got)
    expected = repr(expected)
    message = f"""The test expected:
{expected}

Your output was:
{got}

"""
    results = difflib.ndiff(got, expected)
    result = ""
    for i, s in enumerate(results):
        if s[0] == " ":
            result += s[-1]
            continue

        # there is an error
        if s[0] == "-":
            result += DELETEC
            message += f"Delete {s[-1]} from position {i}\n"
        elif s[0] == "+":
            result += ADDC
            message += f"Add {s[-1]} to position {i}\n"
        result += s[-1].replace(" ", "_")
        result += ENDC

    # rint(message)

    print(
        DELETEC
        + "red "
        + ENDC
        + "characters need to be deleted "
        + ADDC
        + "green"
        + ENDC
        + " characters need to be added. Note that spaces that are missing are replaced with UNDERSCORES '_' so that they may be highlighted):",
        file=sys.stderr,
    )
    print("", file=sys.stderr)
    print(result, file=sys.stderr)
    print("", file=sys.stderr)
    print("", file=sys.stderr)

    assert got == expected, "Sorry your output is not correct"


def compare_expect(got, expected):
    import polynomial

    result = eval(got)
    assert (
        result == expected
    ), f"expected: {got} to return {expected}, but instead got: {result}"


def methods_check(inbound_object, expected_methods={}):
    missing_methods = set()
    for method in expected_methods:
        if method not in dir(inbound_object):
            missing_methods.add(method)
    if len(missing_methods) > 0:
        raise AssertionError(
            f"The following methods are not yet implemented: {', '.join(missing_methods)}"
        )
