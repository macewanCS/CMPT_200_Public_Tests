from otter.test_files import test_case

OK_FORMAT = False

name = "Polynomial"
points = None

@test_case(points=9, hidden=False, 
    success_message="Polynomial methods seem correctly defined for the milestone -- They actually all exist")
def verify_methods(polynomial, test_helpers):
    p = polynomial.Polynomial(())
    assert p is not None, 'Polynomial not correctly defined or not currently imported'
    test_helpers.methods_check(p, {'__init__', 
                                   '__str__', 
                                  'is_zero', 
                                  'eval', 
                                  'degree', 
                                  'lowest_term', 
                                  'horners'})
#verify_methods(polynomial, test_helpers)
@test_case(points=9, hidden=False, 
    success_message="Polynomial str method is correct, 10 marks earned")
def verify_str(polynomial, test_helpers):
    test_helpers.compare_strings('0', str(polynomial.Polynomial()))
    test_helpers.compare_strings('x^2', str(polynomial.Polynomial(((1, 2),))))
    test_helpers.compare_strings('2x^3 + 5x^2 + 6x + 1', str(polynomial.Polynomial(((1, 0), (6, 1), (5, 2), (2, 3)))))
    test_helpers.compare_strings('x^2 + 4', str(polynomial.Polynomial(((1, 2), (4, 0)))))
    test_helpers.compare_strings('x^5 - 3x^3 + x + 4', str(polynomial.Polynomial(((1, 5), (0, 2), (4, 0), (-3, 3), (1, 1)))))
    test_helpers.compare_strings('-3x^3 + x^2 + x - 4', str(polynomial.Polynomial(((1, 2), (0, 2), (-4, 0), (-3, 3), (1, 1)))))
    test_helpers.compare_strings('-5x^6 - 4x^3', str(polynomial.Polynomial(((0, 2), (-4, 3), (-5, 6)))))
    test_helpers.compare_strings('-3x^2', str(polynomial.Polynomial(((1, 2), (-4, 2)))))
    test_helpers.compare_strings('x^5 - 3x^3 + x + 6', str(polynomial.Polynomial(((1, 5), (2, 0), (4, 0), (-3, 3), (1, 1)))))
    test_helpers.compare_strings('-x - 4', str(polynomial.Polynomial(((1, 2), (0, 2), (-4, 0), (3, 3), (-1, 2), (-1, 1), (5, 3), (-8, 3)))))
    test_helpers.compare_strings('0', str(polynomial.Polynomial(((1, 1), (2, 5), (-2, 5), (-1, 1)))))

#verify_str(polynomial, test_helpers)
@test_case(points=9, hidden=False, 
    success_message="Polynomial is_zero method is correct, 10 marks earned")
def check_is_zero(polynomial, test_helpers):
    test_helpers.compare_expect('polynomial.Polynomial(((0, 0),)).is_zero()', True)
    test_helpers.compare_expect('polynomial.Polynomial(((1, 5), (0, 2), (4, 0), (3, 3), (1, 1))).is_zero()',False)
    test_helpers.compare_expect('polynomial.Polynomial(((1, 2), (0, 2), (4, 0), (-4, 0), (-1, 2))).is_zero()',True)
#check_is_zero(polynomial, test_helpers)
@test_case(points=9, hidden=False, 
    success_message="Polynomial lowest_term method is correct, 10 marks earned")
def check_lowest_term(polynomial, test_helpers):
        test_helpers.compare_expect('polynomial.Polynomial(((0, 0),)).lowest_term()',0)
        test_helpers.compare_expect('polynomial.Polynomial(((1, 5), (0, 7), (4, 0), (3, 3), (1, 1))).lowest_term()', 0)
        test_helpers.compare_expect('polynomial.Polynomial(((1, 2), (0, 2), (3, 3), (1, 1))).lowest_term()', 1)
        test_helpers.compare_expect('polynomial.Polynomial(((1, 2), (3, 2), (-5, 3), (-1, 7))).lowest_term()',2)
#check_lowest_term(polynomial, test_helpers)
@test_case(points=9, hidden=False, 
    success_message="Polynomial degree method is correct, 10 marks earned")
def check_degree(polynomial, test_helpers):
        test_helpers.compare_expect('polynomial.Polynomial(((0, 0),)).degree()', 0)
        test_helpers.compare_expect('polynomial.Polynomial(((1, 5), (0, 7), (4, 0), (3, 3), (1, 1))).degree()', 5)
        test_helpers.compare_expect('polynomial.Polynomial(((1, 2), (0, 2), (4, 0), (3, 3), (1, 1))).degree()', 3)
        test_helpers.compare_expect('polynomial.Polynomial(((1, 2), (3, 2), (7, 0), (-5, 3), (-1, 7))).degree()', 7)  

#check_degree(polynomial, test_helpers)
@test_case(points=9, hidden=False, 
    success_message="Polynomial add method is correct, 10 marks earned")
def check_addition(polynomial, test_helpers):

    test_helpers.compare_strings('x', str(polynomial.Polynomial() + polynomial.Polynomial(((1, 1),))))
    test_helpers.compare_strings('2x^5 - 3x', str(polynomial.Polynomial() + polynomial.Polynomial(((3, 5), (-3, 1), (-1, 5)))))
    test_helpers.compare_strings('x^5 + 3x^3 + 7x^2 + 2x + 4', str(polynomial.Polynomial(((1, 1),)) + polynomial.Polynomial(((1, 5), (7, 2), (4, 0), (3, 3), (1, 1)))))
    test_helpers.compare_strings('3x^5 + 3x^3 + 7x^2 - 2x + 4', str(polynomial.Polynomial(((1, 5), (7, 2), (4, 0), (3, 3), (1, 1))) + polynomial.Polynomial(((3, 5), (-3, 1), (-1, 5)))))
    test_helpers.compare_strings('2x^5 - x^3 + 2x^2 - 4x - 4', str(polynomial.Polynomial(((3, 5), (-3, 1), (-1, 5))) + polynomial.Polynomial(((-1, 3), (5, 2), (-4, 0), (-3, 2), (-1, 1)))))
    test_helpers.compare_strings('0', str( polynomial.Polynomial(((-1, 3), (5, 2), (-4, 0), (-3, 2), (-1, 1))) + polynomial.Polynomial(((1, 3), (-5, 2), (4, 0), (3, 2), (1, 1))))) 

#check_addition(polynomial, test_helpers)
@test_case(points=9, hidden=False, 
    success_message="Polynomial can handle basic multiplication, 10 marks earned")
def check_simple_multiplication(polynomial, test_helpers):

    test_helpers.compare_strings('0', str(polynomial.Polynomial(((0, 0),)) * polynomial.Polynomial(((1, 0), (1, 1)))))
    test_helpers.compare_strings('0', str(polynomial.Polynomial(((0, 0),)) * polynomial.Polynomial(((-1, 0), (1, 1)))))
    test_helpers.compare_strings('x^2 - 1', str(polynomial.Polynomial(((1, 0), (1, 1))) * polynomial.Polynomial(((-1, 0), (1, 1)))))
    test_helpers.compare_strings('x + 1', str(polynomial.Polynomial(((1, 0), (1, 1))) * polynomial.Polynomial(((1, 0), ))))
    test_helpers.compare_strings('x - 1', str(polynomial.Polynomial(((-1, 0), (1, 1))) * polynomial.Polynomial(((1, 0),))))

#check_simple_multiplication(polynomial, test_helpers)
@test_case(points=9, hidden=False, 
    success_message="Polynomial can handle basic multiplication, 10 marks earned")
def check_advanced_multiplication(polynomial, test_helpers):

    test_helpers.compare_strings('3x^5 + 9x^3 + 3x + 12', str(polynomial.Polynomial(((3, 0),)) * polynomial.Polynomial(((1, 5), (0, 2), (4, 0), (3, 3), (1, 1)))))
    test_helpers.compare_strings('-x^10 + 3x^9 - 3x^8 + 9x^7 - 4x^6 - x^5 + 3x^4 - 3x^2 - 12x', str(polynomial.Polynomial(((1, 5), (0, 2), (4, 0), (3, 3), (1, 1))) * polynomial.Polynomial(((3, 4), (-3, 1), (-1, 5)))))
    test_helpers.compare_strings('x^10 - 3x^9 + 3x^8 - 9x^7 + 4x^6 + x^5 - 3x^4 + 3x^2 + 12x', str(polynomial.Polynomial(((3, 4), (-3, 1), (-1, 5))) * polynomial.Polynomial(((-1, 5), (0, 2), (-4, 0), (-3, 3), (-1, 1)))))
    test_helpers.compare_strings('x^10 + 6x^8 + 11x^6 + 8x^5 + 6x^4 + 24x^3 + x^2 + 8x + 16', str(polynomial.Polynomial(((-1, 5), (0, 2), (-4, 0), (-3, 3), (-1, 1))) * polynomial.Polynomial(((-1, 5), (0, 2), (-4, 0), (-3, 3), (-1, 1)))))
#check_advanced_multiplication(polynomial, test_helpers)
@test_case(points=9, hidden=False, 
    success_message="Polynomial eval method works, 10 marks earned")
def check_eval(polynomial, test_helpers):
    for x in range(30):
        test_helpers.compare_expect(f'polynomial.Polynomial().eval({x})', 0)    
        test_helpers.compare_expect(f'polynomial.Polynomial(((1, 1),)).eval({x})', x) 
        test_helpers.compare_expect(f'polynomial.Polynomial(((1, 5), (7, 2), (4, 0), (3, 3), (1, 1))).eval({x})', x**5+3*x**3+7*x**2+x+4)
        test_helpers.compare_expect(f'polynomial.Polynomial(((3, 5), (-3, 1), (-1, 5))).eval({x})', 2*x**5-3*x)
        test_helpers.compare_expect(f'polynomial.Polynomial(((-1, 3), (5, 2), (-4, 0), (-3, 2), (-1, 1))).eval({x})', -x**3+2*x**2-x-4)
        test_helpers.compare_expect(f'polynomial.Polynomial(((1, 3), (-5, 2), (4, 0), (3, 2), (1, 1))) .eval({x})', x**3-2*x**2+x+4)
#check_eval(polynomial, test_helpers)
@test_case(points=9, hidden=False, 
    success_message="Horners method works, 10 marks earned")
def check_horners(polynomial, test_helpers):
        test_helpers.compare_strings('0',polynomial.Polynomial().horners())
        test_helpers.compare_strings('x',polynomial.Polynomial([(1, 1)]).horners())
        test_helpers.compare_strings('-x',polynomial.Polynomial(((-1, 1),)).horners())
        test_helpers.compare_strings('x(x(x(x(x)+3)+7)+1)4',polynomial.Polynomial(((1, 5),(3, 3), (7, 2), (1, 1), (4, 0))).horners())
        test_helpers.compare_strings('x(x(x(x(2x)))-3)',polynomial.Polynomial(((2, 5), (-3, 1))).horners())
        test_helpers.compare_strings('x(x(-x+2)-1)-4',polynomial.Polynomial(((-1, 3), (2, 2), (-1, 1),(-4, 0))).horners())
        test_helpers.compare_strings('x(x(x-2)+1)4',polynomial.Polynomial(((1, 3), (-2, 2), (1, 1), (4, 0))).horners())
        test_helpers.compare_strings('x(x(x(-4x)))',polynomial.Polynomial(( (-4, 4),)).horners())
        test_helpers.compare_strings('x(x(x(x(x(x(x(2x))-3))))+1)',polynomial.Polynomial(((2,8),(-3,5),(1,1))).horners())

#check_horners(polynomial, test_helpers)
