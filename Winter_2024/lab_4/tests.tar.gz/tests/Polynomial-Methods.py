from otter.test_files import test_case

OK_FORMAT = False

name = "Polynomial-Methods"
points = None

@test_case(points=5, hidden=False, 
    success_message="Polynomial methods seem correctly defined for the milestone -- They actually all exist")
def verify_methods(polynomial, test_helpers):
    p = polynomial.Polynomial(())
    assert p is not None, 'Polynomial not correctly defined or not currently imported'
    test_helpers.methods_check(p, {'__init__', 
                                   '__str__', 
                                  'is_zero', 
                                  'eval', 
                                  'degree', 
                                  'lowest_term', 
                                  'horners'})
#verify_methods(polynomial, test_helpers)
