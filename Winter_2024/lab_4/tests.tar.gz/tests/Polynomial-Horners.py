from otter.test_files import test_case

OK_FORMAT = False

name = "Polynomial-Horners"
points = None

@test_case(points=9, hidden=False, 
    success_message="Horners method works")
def check_horners(polynomial, test_helpers):
    test_helpers.compare_strings('0',polynomial.Polynomial().horners())
@test_case(points=None, hidden=False)
def check_horners_1(polynomial, test_helpers):
    test_helpers.compare_strings('x',polynomial.Polynomial([(1, 1)]).horners())
@test_case(points=None, hidden=False)
def check_horners_2(polynomial, test_helpers):
    test_helpers.compare_strings('-x',polynomial.Polynomial(((-1, 1),)).horners())
@test_case(points=None, hidden=False)
def check_horners_3(polynomial, test_helpers):
    test_helpers.compare_strings('x(x(x(x(x)+3)+7)+1)4',polynomial.Polynomial(((1, 5),(3, 3), (7, 2), (1, 1), (4, 0))).horners())
@test_case(points=None, hidden=False)
def check_horners_4(polynomial, test_helpers):
    test_helpers.compare_strings('x(x(x(x(2x)))-3)',polynomial.Polynomial(((2, 5), (-3, 1))).horners())
@test_case(points=None, hidden=False)
def check_horners_5(polynomial, test_helpers):
    test_helpers.compare_strings('x(x(-x+2)-1)-4',polynomial.Polynomial(((-1, 3), (2, 2), (-1, 1),(-4, 0))).horners())
@test_case(points=None, hidden=False)
def check_horners_6(polynomial, test_helpers):
    test_helpers.compare_strings('x(x(x-2)+1)4',polynomial.Polynomial(((1, 3), (-2, 2), (1, 1), (4, 0))).horners())
@test_case(points=None, hidden=False)
def check_horners_7(polynomial, test_helpers):
    test_helpers.compare_strings('x(x(x(-4x)))',polynomial.Polynomial(( (-4, 4),)).horners())
@test_case(points=None, hidden=False)
def check_horners_8(polynomial, test_helpers):
    test_helpers.compare_strings('x(x(x(x(x(x(x(2x))-3))))+1)',polynomial.Polynomial(((2,8),(-3,5),(1,1))).horners())
