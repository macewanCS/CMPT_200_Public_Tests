from otter.test_files import test_case

OK_FORMAT = False

name = "Polynomial-is_zero"
points = None

@test_case(points=1, hidden=False)
def check_is_zero(polynomial, test_helpers):
    test_helpers.compare_expect('polynomial.Polynomial(((0, 0),)).is_zero()', True)
@test_case(points=1, hidden=False)
def check_is_zero_1(polynomial, test_helpers):
    test_helpers.compare_expect('polynomial.Polynomial(((1, 5), (0, 2), (4, 0), (3, 3), (1, 1))).is_zero()',False)
@test_case(points=1, hidden=False)
def check_is_zero_2(polynomial, test_helpers):
    test_helpers.compare_expect('polynomial.Polynomial(((1, 2), (0, 2), (4, 0), (-4, 0), (-1, 2))).is_zero()',True)
