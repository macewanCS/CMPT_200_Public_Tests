from otter.test_files import test_case

OK_FORMAT = False

name = "Polynomial-Simple_Multiplication"
points = None

@test_case(points=9, hidden=False, 
    success_message="Polynomial can handle basic multiplication")
def check_simple_multiplication(polynomial, test_helpers):
    test_helpers.compare_strings('0', str(polynomial.Polynomial(((0, 0),)) * polynomial.Polynomial(((1, 0), (1, 1)))))
def check_simple_multiplication_1(polynomial, test_helpers):
    test_helpers.compare_strings('0', str(polynomial.Polynomial(((0, 0),)) * polynomial.Polynomial(((-1, 0), (1, 1)))))
def check_simple_multiplication_2(polynomial, test_helpers):
    test_helpers.compare_strings('x^2 - 1', str(polynomial.Polynomial(((1, 0), (1, 1))) * polynomial.Polynomial(((-1, 0), (1, 1)))))
def check_simple_multiplication_3(polynomial, test_helpers):
    test_helpers.compare_strings('x + 1', str(polynomial.Polynomial(((1, 0), (1, 1))) * polynomial.Polynomial(((1, 0), ))))
def check_simple_multiplication_4(polynomial, test_helpers):
    test_helpers.compare_strings('x - 1', str(polynomial.Polynomial(((-1, 0), (1, 1))) * polynomial.Polynomial(((1, 0),))))

#check_simple_multiplication(polynomial, test_helpers)
