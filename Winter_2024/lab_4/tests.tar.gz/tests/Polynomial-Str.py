from otter.test_files import test_case

OK_FORMAT = False

name = "Polynomial-Str"
points = None

@test_case(points=None, hidden=False, 
    success_message="Polynomial str method is correct")
def verify_str(polynomial, test_helpers):
    test_helpers.compare_strings('0', str(polynomial.Polynomial()))
def verify_str_1(polynomial, test_helpers):
    test_helpers.compare_strings('x^2', str(polynomial.Polynomial(((1, 2),))))
def verify_str_2(polynomial, test_helpers):
    test_helpers.compare_strings('2x^3 + 5x^2 + 6x + 1', str(polynomial.Polynomial(((1, 0), (6, 1), (5, 2), (2, 3)))))
def verify_str_3(polynomial, test_helpers):
    test_helpers.compare_strings('x^2 + 4', str(polynomial.Polynomial(((1, 2), (4, 0)))))
def verify_str_4(polynomial, test_helpers):
    test_helpers.compare_strings('x^5 - 3x^3 + x + 4', str(polynomial.Polynomial(((1, 5), (0, 2), (4, 0), (-3, 3), (1, 1)))))
def verify_str_5(polynomial, test_helpers):
    test_helpers.compare_strings('-3x^3 + x^2 + x - 4', str(polynomial.Polynomial(((1, 2), (0, 2), (-4, 0), (-3, 3), (1, 1)))))
def verify_str_6(polynomial, test_helpers):
    test_helpers.compare_strings('-5x^6 - 4x^3', str(polynomial.Polynomial(((0, 2), (-4, 3), (-5, 6)))))
def verify_str_7(polynomial, test_helpers):
    test_helpers.compare_strings('-3x^2', str(polynomial.Polynomial(((1, 2), (-4, 2)))))
def verify_str_8(polynomial, test_helpers):
    test_helpers.compare_strings('x^5 - 3x^3 + x + 6', str(polynomial.Polynomial(((1, 5), (2, 0), (4, 0), (-3, 3), (1, 1)))))
def verify_str_9(polynomial, test_helpers):
    test_helpers.compare_strings('-x - 4', str(polynomial.Polynomial(((1, 2), (0, 2), (-4, 0), (3, 3), (-1, 2), (-1, 1), (5, 3), (-8, 3)))))y
def verify_str_10(polynomial, test_helpers):
    test_helpers.compare_strings('0', str(polynomial.Polynomial(((1, 1), (2, 5), (-2, 5), (-1, 1)))))

#verify_str(polynomial, test_helpers)
