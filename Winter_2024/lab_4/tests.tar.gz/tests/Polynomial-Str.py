from otter.test_files import test_case

OK_FORMAT = False

name = "Polynomial-Str"
points = None

@test_case(points=9, hidden=False, 
    success_message="Polynomial str method is correct, 10 marks earned")
def verify_str(polynomial, test_helpers):
    test_helpers.compare_strings('0', str(polynomial.Polynomial()))
    test_helpers.compare_strings('x^2', str(polynomial.Polynomial(((1, 2),))))
    test_helpers.compare_strings('2x^3 + 5x^2 + 6x + 1', str(polynomial.Polynomial(((1, 0), (6, 1), (5, 2), (2, 3)))))
    test_helpers.compare_strings('x^2 + 4', str(polynomial.Polynomial(((1, 2), (4, 0)))))
    test_helpers.compare_strings('x^5 - 3x^3 + x + 4', str(polynomial.Polynomial(((1, 5), (0, 2), (4, 0), (-3, 3), (1, 1)))))
    test_helpers.compare_strings('-3x^3 + x^2 + x - 4', str(polynomial.Polynomial(((1, 2), (0, 2), (-4, 0), (-3, 3), (1, 1)))))
    test_helpers.compare_strings('-5x^6 - 4x^3', str(polynomial.Polynomial(((0, 2), (-4, 3), (-5, 6)))))
    test_helpers.compare_strings('-3x^2', str(polynomial.Polynomial(((1, 2), (-4, 2)))))
    test_helpers.compare_strings('x^5 - 3x^3 + x + 6', str(polynomial.Polynomial(((1, 5), (2, 0), (4, 0), (-3, 3), (1, 1)))))
    test_helpers.compare_strings('-x - 4', str(polynomial.Polynomial(((1, 2), (0, 2), (-4, 0), (3, 3), (-1, 2), (-1, 1), (5, 3), (-8, 3)))))
    test_helpers.compare_strings('0', str(polynomial.Polynomial(((1, 1), (2, 5), (-2, 5), (-1, 1)))))

#verify_str(polynomial, test_helpers)
