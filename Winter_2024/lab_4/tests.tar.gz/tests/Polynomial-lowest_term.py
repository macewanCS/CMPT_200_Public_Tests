from otter.test_files import test_case

OK_FORMAT = False

name = "Polynomial-lowest_term"
points = None

@test_case(points=1, hidden=False)
def check_lowest_term(polynomial, test_helpers):
        test_helpers.compare_expect('polynomial.Polynomial(((0, 0),)).lowest_term()',0)
@test_case(points=1, hidden=False)
def check_lowest_term_1(polynomial, test_helpers):
        test_helpers.compare_expect('polynomial.Polynomial(((1, 5), (0, 7), (4, 0), (3, 3), (1, 1))).lowest_term()', 0)
@test_case(points=1, hidden=False)
def check_lowest_term_2(polynomial, test_helpers):
        test_helpers.compare_expect('polynomial.Polynomial(((1, 2), (0, 2), (3, 3), (1, 1))).lowest_term()', 1)
@test_case(points=1, hidden=False)
def check_lowest_term_3(polynomial, test_helpers):
        test_helpers.compare_expect('polynomial.Polynomial(((1, 2), (3, 2), (-5, 3), (-1, 7))).lowest_term()',2)
