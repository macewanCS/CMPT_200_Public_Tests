from otter.test_files import test_case

OK_FORMAT = False

name = "Polynomial-Advanced_Multiplication"
points = None

@test_case(points=9, hidden=False, 
    success_message="Polynomial can handle advanced multiplication, 10 marks earned")
def check_advanced_multiplication(polynomial, test_helpers):

    test_helpers.compare_strings('3x^5 + 9x^3 + 3x + 12', str(polynomial.Polynomial(((3, 0),)) * polynomial.Polynomial(((1, 5), (0, 2), (4, 0), (3, 3), (1, 1)))))
    test_helpers.compare_strings('-x^10 + 3x^9 - 3x^8 + 9x^7 - 4x^6 - x^5 + 3x^4 - 3x^2 - 12x', str(polynomial.Polynomial(((1, 5), (0, 2), (4, 0), (3, 3), (1, 1))) * polynomial.Polynomial(((3, 4), (-3, 1), (-1, 5)))))
    test_helpers.compare_strings('x^10 - 3x^9 + 3x^8 - 9x^7 + 4x^6 + x^5 - 3x^4 + 3x^2 + 12x', str(polynomial.Polynomial(((3, 4), (-3, 1), (-1, 5))) * polynomial.Polynomial(((-1, 5), (0, 2), (-4, 0), (-3, 3), (-1, 1)))))
    test_helpers.compare_strings('x^10 + 6x^8 + 11x^6 + 8x^5 + 6x^4 + 24x^3 + x^2 + 8x + 16', str(polynomial.Polynomial(((-1, 5), (0, 2), (-4, 0), (-3, 3), (-1, 1))) * polynomial.Polynomial(((-1, 5), (0, 2), (-4, 0), (-3, 3), (-1, 1)))))
#check_advanced_multiplication(polynomial, test_helpers)
