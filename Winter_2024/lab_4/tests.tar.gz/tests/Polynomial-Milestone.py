from otter.test_files import test_case

OK_FORMAT = False

name = "Polynomial-Milestone"
points = None

@test_case(points=1, hidden=False, 
    success_message="Polynomial methods seem correctly defined for the milestone -- They actually all exist")
def verify_methods(polynomial, test_helpers):
    p = polynomial.Polynomial(())
    assert p is not None, 'Polynomial not correctly defined or not currently imported'
    test_helpers.methods_check(p, {'__init__', 
                                   '__str__', })
#verify_methods(polynomial, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Polynomial str method is correct for a single x")
def verify_1x(polynomial, test_helpers):
    p = polynomial.Polynomial(((1,1),))
    test_helpers.compare_strings('x', str(p)) 
#verify_1x(polynomial, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Polynomial str method is correct for 3x^2")
def verify_3x2(polynomial, test_helpers):
    p = polynomial.Polynomial(((3,2),))
    test_helpers.compare_strings('3x^2', str(p)) 
#verify_3x2(polynomial, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Polynomial str method is correct for 3x^2 + 2x + 1")
def verify_three_term(polynomial, test_helpers):
    p = polynomial.Polynomial(((3,2),(2,1),(1,0)))
    test_helpers.compare_strings('3x^2 + 2x + 1', str(p)) 
#verify_three_term(polynomial, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Polynomial str method is correct for 3x^2 + 2x + 1 when it is provided out of order")
def verify_three_term_out_of_order(polynomial, test_helpers):
    p = polynomial.Polynomial(((1,0),(3,2),(2,1)))
    test_helpers.compare_strings('3x^2 + 2x + 1', str(p)) 
#verify_three_term_out_of_order(polynomial, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Polynomial str method is correct for -3x^2 + 2x - 1 when it is provided out of order")
def verify_negative(polynomial, test_helpers):
    p = polynomial.Polynomial(((-1,0),(-3,2),(2,1)))
    test_helpers.compare_strings('-3x^2 + 2x - 1', str(p)) 
#verify_negative(polynomial, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Polynomial str method is correct for zero degree polynomial")
def verify_zero(polynomial, test_helpers):
    p = polynomial.Polynomial(())
    test_helpers.compare_strings('0', str(p)) 
#verify_zero(polynomial, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Polynomial is able to collect single like terms correctly")
def verify_collection(polynomial, test_helpers):
    p = polynomial.Polynomial(((-1,0),(3,2),(2,0)))
    test_helpers.compare_strings('3x^2 + 1', str(p)) 
#verify_collection(polynomial, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Polynomial is able to collect many like terms correctly")
def verify_collection_many(polynomial, test_helpers):
    p = polynomial.Polynomial(((-1,0),(3,2),(2,0), (5, 2), (3, 6), (-2, 6)))
    test_helpers.compare_strings('x^6 + 8x^2 + 1', str(p)) 
#verify_collection_many(polynomial, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Polynomial is able to collect many like terms correctly, removing them completely when they zero")
def verify_collection_many_zeroed(polynomial, test_helpers):
    p = polynomial.Polynomial(((-1,0),(-3, 6),(3,2),(2,0),(5, 2),(3, 6),))
    test_helpers.compare_strings('8x^2 + 1', str(p)) 
#verify_collection_many_zeroed(polynomial, test_helpers)
