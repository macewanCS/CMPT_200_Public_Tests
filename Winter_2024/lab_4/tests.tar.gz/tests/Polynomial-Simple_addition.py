from otter.test_files import test_case

OK_FORMAT = False

name = "Polynomial-Simple_addition"
points = None

@test_case(points=1, hidden=False, 
    success_message="Polynomial add method is correct")
def check_addition(polynomial, test_helpers):
    test_helpers.compare_strings('x', str(polynomial.Polynomial() + polynomial.Polynomial(((1, 1),))))
@test_case(points=1, hidden=False)
def check_addition_1(polynomial, test_helpers):
    test_helpers.compare_strings('2x^5 - 3x', str(polynomial.Polynomial() + polynomial.Polynomial(((3, 5), (-3, 1), (-1, 5)))))
@test_case(points=1, hidden=False)
def check_addition_2(polynomial, test_helpers):
    test_helpers.compare_strings('x^5 + 3x^3 + 7x^2 + 2x + 4', str(polynomial.Polynomial(((1, 1),)) + polynomial.Polynomial(((1, 5), (7, 2), (4, 0), (3, 3), (1, 1)))))
@test_case(points=1, hidden=False)
def check_addition_3(polynomial, test_helpers):
    test_helpers.compare_strings('3x^5 + 3x^3 + 7x^2 - 2x + 4', str(polynomial.Polynomial(((1, 5), (7, 2), (4, 0), (3, 3), (1, 1))) + polynomial.Polynomial(((3, 5), (-3, 1), (-1, 5)))))
@test_case(points=1, hidden=False)
def check_addition_4(polynomial, test_helpers):
    test_helpers.compare_strings('2x^5 - x^3 + 2x^2 - 4x - 4', str(polynomial.Polynomial(((3, 5), (-3, 1), (-1, 5))) + polynomial.Polynomial(((-1, 3), (5, 2), (-4, 0), (-3, 2), (-1, 1)))))
@test_case(points=1, hidden=False)
def check_addition_5(polynomial, test_helpers):
    test_helpers.compare_strings('0', str( polynomial.Polynomial(((-1, 3), (5, 2), (-4, 0), (-3, 2), (-1, 1))) + polynomial.Polynomial(((1, 3), (-5, 2), (4, 0), (3, 2), (1, 1))))) 
