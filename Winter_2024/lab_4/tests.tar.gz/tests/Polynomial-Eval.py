from otter.test_files import test_case

OK_FORMAT = False

name = "Polynomial-Eval"
points = None

@test_case(points=9, hidden=False, 
    success_message="Polynomial eval method works, 10 marks earned")
def check_eval(polynomial, test_helpers):
    for x in range(30):
        test_helpers.compare_expect(f'polynomial.Polynomial().eval({x})', 0)    
        test_helpers.compare_expect(f'polynomial.Polynomial(((1, 1),)).eval({x})', x) 
        test_helpers.compare_expect(f'polynomial.Polynomial(((1, 5), (7, 2), (4, 0), (3, 3), (1, 1))).eval({x})', x**5+3*x**3+7*x**2+x+4)
        test_helpers.compare_expect(f'polynomial.Polynomial(((3, 5), (-3, 1), (-1, 5))).eval({x})', 2*x**5-3*x)
        test_helpers.compare_expect(f'polynomial.Polynomial(((-1, 3), (5, 2), (-4, 0), (-3, 2), (-1, 1))).eval({x})', -x**3+2*x**2-x-4)
        test_helpers.compare_expect(f'polynomial.Polynomial(((1, 3), (-5, 2), (4, 0), (3, 2), (1, 1))) .eval({x})', x**3-2*x**2+x+4)
#check_eval(polynomial, test_helpers)
