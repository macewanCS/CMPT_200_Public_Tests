from otter.test_files import test_case

OK_FORMAT = False

name = "Polynomial-degree"
points = None

@test_case(points=None, hidden=False)
def check_degree(polynomial, test_helpers):
        test_helpers.compare_expect('polynomial.Polynomial(((0, 0),)).degree()', 0)
@test_case(points=None, hidden=False)
def check_degree_1(polynomial, test_helpers):
        test_helpers.compare_expect('polynomial.Polynomial(((1, 5), (0, 7), (4, 0), (3, 3), (1, 1))).degree()', 5)
@test_case(points=None, hidden=False)
def check_degree_2(polynomial, test_helpers):
        test_helpers.compare_expect('polynomial.Polynomial(((1, 2), (0, 2), (4, 0), (3, 3), (1, 1))).degree()', 3)
@test_case(points=None, hidden=False)
def check_degree_3(polynomial, test_helpers):
        test_helpers.compare_expect('polynomial.Polynomial(((1, 2), (3, 2), (7, 0), (-5, 3), (-1, 7))).degree()', 7)  

#check_degree(polynomial, test_helpers)
