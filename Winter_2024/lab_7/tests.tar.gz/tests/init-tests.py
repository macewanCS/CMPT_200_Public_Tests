from otter.test_files import test_case

OK_FORMAT = False

name = "init-tests"
points = None

@test_case(points=5, hidden=False, 
    success_message="BST Methods Defined!")
def verify_methods(bst, test_helpers):
    t = bst.Tree()
    assert t is not None, 'Tree not correctly imported or init is incorrect'
    test_helpers.methods_check(t, {'__init__', 
                                   '__repr__', 'read_filename', 'first', 'last', 'most', 'summary', 'search', 'delete', 'levels'})
#verify_methods(bst, test_helpers)
@test_case(points=50, hidden=False, 
    success_message="short.txt seems to work correctly")
def verify_short(bst, test_helpers):
    t = bst.Tree()
    firsts = ['across', 'and','bird','black','brown']
    lasts = ['zebra', 'yellow', 'to', 'then', 'the']
    assert t.first() is None, 'First should return None on an empty tree'
    t.read_filename('short.txt')
    test_helpers.compare_strings('''Depth 6: lazy[1]
Depth 5: over[1], it[1], bird[1], across[1]
Depth 4: yellow[1], see[1], jumped[1], dog[1], and[2]
Depth 3: zebra[1], river[1], fox[1], black[1]
Depth 2: to[1], swam[1], brown[1]
Depth 1: then[1], quick[1]
Depth 0: the[4]''', t.levels())
    for i in range(5):
        test_helpers.compare_strings(firsts.pop(0), t.first())
        t.delete(t.first())
        assert t.most() == ({'the'}, 4), f"{{'the'}} should be the most common word(s) with a count of 4, but you gave {t.most()}"
        test_helpers.compare_strings(lasts.pop(0), t.last())
        t.delete(t.last())
        if i == 4: # the is removed which means everything left is most common
            expects = {'over', 'lazy', 'jumped', 'quick', 'see', 'river', 'swam', 'it', 'fox', 'dog'}
            assert t.most() == (expects, 1), f"{expects} should be the most common words with a count of 1, but you gave {t.most()}"
    test_helpers.compare_strings('''== Statistics ==
Height of tree: 4
Total words: 10
Distinct words: 10
First: dog
Last: swam''', t.summary().strip())
    test_helpers.compare_strings('''Depth 4: lazy[1]
Depth 3: see[1], over[1], it[1]
Depth 2: river[1], jumped[1], dog[1]
Depth 1: swam[1], fox[1]
Depth 0: quick[1]''', t.levels())
#verify_short(bst, test_helpers)
@test_case(points=20, hidden=False, 
    success_message="medium.txt seems to work correctly")
def verify_medium(bst, test_helpers):
    t = bst.Tree()
    firsts = ['0', '000','014','1','100']
    lasts = ["zipf's", 'zipf', 'years', 'written', 'works']
    assert t.first() is None, 'First should return None on an empty tree'
    t.read_filename('medium.txt')
    test_helpers.first_and_last_line(t.levels(),'Depth 17: upper[1]', 'Depth 0: in[16]')
    for i in range(5):
        test_helpers.compare_strings(firsts.pop(0), t.first())
        t.delete(t.first())
        assert t.most() == ({'the'}, 42), f"{{'the'}} should be the most common word(s) with a count of 42, but you gave {t.most()}"
        test_helpers.compare_strings(lasts.pop(0), t.last())
        t.delete(t.last())
    test_helpers.compare_strings('''== Statistics ==
Height of tree: 17
Total words: 734
Distinct words: 362
First: 15
Last: work''', t.summary().strip())

    test_helpers.first_and_last_line(t.levels(),'Depth 17: upper[1]', 'Depth 0: in[16]')
    assert t.delete('in'), 'Delete of "in" did not return True'
    assert t.delete('upper'), 'Delete of "work" failed'
    assert not t.delete('srietnie'), 'Delete of nonsense word succeded (it should fail)'
    test_helpers.first_and_last_line(t.levels(),'Depth 16: up[1]', 'Depth 0: indicated[1]')
#verify_medium(bst, test_helpers)
@test_case(points=15, hidden=False, 
    success_message="both files seem to work correctly")
def verify_both(bst, test_helpers):
    t = bst.Tree()
    firsts = ['0', '000','014','1','100']
    lasts = ["zipf's", 'zipf', "zebra", 'yellow', 'years']
    assert t.first() is None, 'First should return None on an empty tree'
    t.read_filename('medium.txt')
    t.read_filename('short.txt')
    test_helpers.first_and_last_line(t.levels(),'Depth 17: upper[1]', 'Depth 0: in[16]')
    for i in range(5):
        test_helpers.compare_strings(firsts.pop(0), t.first())
        t.delete(t.first())
        assert t.most() == ({'the'}, 46), f"{{'the'}} should be the most common word(s) with a count of 46, but you gave {t.most()}"
        test_helpers.compare_strings(lasts.pop(0), t.last())
        t.delete(t.last())
    test_helpers.compare_strings('''== Statistics ==
Height of tree: 17
Total words: 758
Distinct words: 373
First: 15
Last: written''', t.summary().strip())

    test_helpers.first_and_last_line(t.levels(),'Depth 17: upper[1]', 'Depth 0: in[16]')
    assert t.delete('in'), 'Delete of "in" did not return True'
    assert t.delete('upper'), 'Delete of "work" failed'
    assert not t.delete('srietnie'), 'Delete of nonsense word succeded (it should fail)'
    test_helpers.first_and_last_line(t.levels(),'Depth 16: up[1]', 'Depth 0: indicated[1]')
#verify_both(bst, test_helpers)
@test_case(points=10, hidden=False, 
    success_message="both files seem to work correctly")
def verify_opposite(bst, test_helpers):
    t = bst.Tree()
    firsts = ['0', '000','014','1','100']
    lasts = ["zipf's", 'zipf', "zebra", 'yellow', 'years']
    assert t.first() is None, 'First should return None on an empty tree'
    t.read_filename('short.txt')
    t.read_filename('medium.txt')
    test_helpers.first_and_last_line(t.levels(),'Depth 18: upper[1]', 'Depth 0: the[46]')
    for i in range(5):
        test_helpers.compare_strings(firsts.pop(0), t.first())
        t.delete(t.first())
        assert t.most() == ({'the'}, 46), f"{{'the'}} should be the most common word(s) with a count of 46, but you gave {t.most()}"
        test_helpers.compare_strings(lasts.pop(0), t.last())
        t.delete(t.last())
    test_helpers.compare_strings('''== Statistics ==
Height of tree: 16
Total words: 758
Distinct words: 373
First: 15
Last: written''', t.summary().strip())
    t.delete('native')
    t.delete('upper')
    test_helpers.first_and_last_line(t.levels(),'Depth 16: narrowly[1]', 'Depth 0: the[46]')
#verify_opposite(bst, test_helpers)
