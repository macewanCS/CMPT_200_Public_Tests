from otter.test_files import test_case

OK_FORMAT = False

name = "both"
points = None

@test_case(points=15, hidden=False, 
    success_message="both files seem to work correctly")
def verify_both(bst, test_helpers):
    t = bst.Tree()
    firsts = ['0', '000','014','1','100']
    lasts = ["zipf's", 'zipf', "zebra", 'yellow', 'years']
    assert t.first() is None, 'First should return None on an empty tree'
    t.read_filename('medium.txt')
    t.read_filename('short.txt')
    test_helpers.first_and_last_line(t.levels(),'Depth 17: upper[1]', 'Depth 0: in[16]')
    for i in range(5):
        test_helpers.compare_strings(firsts.pop(0), t.first())
        t.delete(t.first())
        assert t.most() == ({'the'}, 46), f"{{'the'}} should be the most common word(s) with a count of 46, but you gave {t.most()}"
        test_helpers.compare_strings(lasts.pop(0), t.last())
        t.delete(t.last())
    test_helpers.compare_strings('''== Statistics ==
Height of tree: 17
Total words: 758
Distinct words: 373
First: 15
Last: written''', t.summary().strip())

    test_helpers.first_and_last_line(t.levels(),'Depth 17: upper[1]', 'Depth 0: in[16]')
    assert t.delete('in'), 'Delete of "in" did not return True'
    assert t.delete('upper'), 'Delete of "work" failed'
    assert not t.delete('srietnie'), 'Delete of nonsense word succeded (it should fail)'
    test_helpers.first_and_last_line(t.levels(),'Depth 16: up[1]', 'Depth 0: indicated[1]')
#verify_both(bst, test_helpers)
