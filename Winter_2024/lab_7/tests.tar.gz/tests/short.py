from otter.test_files import test_case

OK_FORMAT = False

name = "short"
points = None

@test_case(points=50, hidden=False, 
    success_message="short.txt seems to work correctly")
def verify_short(bst, test_helpers):
    t = bst.Tree()
    firsts = ['across', 'and','bird','black','brown']
    lasts = ['zebra', 'yellow', 'to', 'then', 'the']
    assert t.first() is None, 'First should return None on an empty tree'
    t.read_filename('short.txt')
    test_helpers.compare_strings('''Depth 6: lazy[1]
Depth 5: over[1], it[1], bird[1], across[1]
Depth 4: yellow[1], see[1], jumped[1], dog[1], and[2]
Depth 3: zebra[1], river[1], fox[1], black[1]
Depth 2: to[1], swam[1], brown[1]
Depth 1: then[1], quick[1]
Depth 0: the[4]''', t.levels())
    for i in range(5):
        test_helpers.compare_strings(firsts.pop(0), t.first())
        t.delete(t.first())
        assert t.most() == ({'the'}, 4), f"{{'the'}} should be the most common word(s) with a count of 4, but you gave {t.most()}"
        test_helpers.compare_strings(lasts.pop(0), t.last())
        t.delete(t.last())
        if i == 4: # the is removed which means everything left is most common
            expects = {'over', 'lazy', 'jumped', 'quick', 'see', 'river', 'swam', 'it', 'fox', 'dog'}
            assert t.most() == (expects, 1), f"{expects} should be the most common words with a count of 1, but you gave {t.most()}"
    test_helpers.compare_strings('''== Statistics ==
Height of tree: 4
Total words: 10
Distinct words: 10
First: dog
Last: swam''', t.summary().strip())
    test_helpers.compare_strings('''Depth 4: lazy[1]
Depth 3: see[1], over[1], it[1]
Depth 2: river[1], jumped[1], dog[1]
Depth 1: swam[1], fox[1]
Depth 0: quick[1]''', t.levels())
#verify_short(bst, test_helpers)
