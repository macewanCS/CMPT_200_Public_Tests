from otter.test_files import test_case

OK_FORMAT = False

name = "opposite"
points = None

@test_case(points=10, hidden=False, 
    success_message="both files seem to work correctly")
def verify_opposite(bst, test_helpers):
    t = bst.Tree()
    firsts = ['0', '000','014','1','100']
    lasts = ["zipf's", 'zipf', "zebra", 'yellow', 'years']
    assert t.first() is None, 'First should return None on an empty tree'
    t.read_filename('short.txt')
    t.read_filename('medium.txt')
    test_helpers.first_and_last_line(t.levels(),'Depth 18: upper[1]', 'Depth 0: the[46]')
    for i in range(5):
        test_helpers.compare_strings(firsts.pop(0), t.first())
        t.delete(t.first())
        assert t.most() == ({'the'}, 46), f"{{'the'}} should be the most common word(s) with a count of 46, but you gave {t.most()}"
        test_helpers.compare_strings(lasts.pop(0), t.last())
        t.delete(t.last())
    test_helpers.compare_strings('''== Statistics ==
Height of tree: 16
Total words: 758
Distinct words: 373
First: 15
Last: written''', t.summary().strip())
    t.delete('native')
    t.delete('upper')
    test_helpers.first_and_last_line(t.levels(),'Depth 16: narrowly[1]', 'Depth 0: the[46]')
#verify_opposite(bst, test_helpers)
