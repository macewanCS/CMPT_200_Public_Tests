from otter.test_files import test_case

OK_FORMAT = False

name = "init"
points = None

@test_case(points=5, hidden=False, 
    success_message="BST Methods Defined!")
def verify_methods(bst, test_helpers):
    t = bst.Tree()
    assert t is not None, 'Tree not correctly imported or init is incorrect'
    test_helpers.methods_check(t, {'__init__', 
                                   '__repr__', 'read_filename', 'first', 'last', 'most', 'summary', 'search', 'delete', 'levels'})
#verify_methods(bst, test_helpers)
