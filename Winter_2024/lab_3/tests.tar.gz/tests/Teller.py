from otter.test_files import test_case

OK_FORMAT = False

name = "Teller"
points = None

@test_case(points=1, hidden=False, 
    success_message="Teller methods seem correctly defined -- They actually all exist")
def test_1(banking, test_helpers):
    teller_name = 2
    t = banking.Teller(name=teller_name)
    assert t is not None, 'Teller not imported or not defined'
    test_helpers.methods_check(t, {'__init__',
                               '__str__',
                               'service', 
                               'accept',
                               'get_total_service_time', 
                               'make_available',
                                   'is_available'})
    assert t.is_available(), 'Teller should start ready for work!'
#test_1(banking, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="String method exists, and works for zero time")
def test_teller_str(banking, test_helpers):
    teller_name = 2
    t = banking.Teller(name=teller_name)
    test_helpers.compare_strings(str(t), 'Teller: 2 Total service time: 0')
#test_teller_str(banking, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Teller can service simple customers that are completed fully")
def test_teller_accept_and_run(banking, test_helpers):
    teller_name = 1
    t = banking.Teller(name=teller_name)
    def expected_service_time(expected):
        assert (ans:=t.get_total_service_time()) == expected, f'Service time should have been: {expected}, but was {ans}'
        test_helpers.compare_strings(str(t), f'Teller: 1 Total service time: {expected}')
    for x in range(10):
        t.accept(1)
        assert not t.is_available(), f'Teller should not be available after accepting 1 unit of work on the {x} iteration'
        expected_service_time(x)
        t.service(1)
        assert t.is_available(), f'Teller should be available after completing 1 unit work on the {x} iteration'
        expected_service_time(x+1)
    for x in range(0,10,2):
        assert t.is_available(), f'Teller should be available before receiving work on the {(x//2)+10} iteration'
        t.accept(2)
        assert not t.is_available(), f'Teller should not be available after receiving work on the {(x//2)+10} iteration'
        expected_service_time(x+10)
        t.service(2)
        assert t.is_available(), f'Teller should be available after servicing work on the {(x//2)+10} iteration'
        expected_service_time(x+10+2)
#test_teller_accept_and_run(banking, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Teller can service complex customers that are not completed fully")
def test_teller_accept_and_run_incomplete(banking, test_helpers):
    teller_name = 1
    t = banking.Teller(name=teller_name)
    def expected_service_time(expected):
        assert (ans:=t.get_total_service_time()) == expected, f'Service time should have been: {expected}, but was {ans}'
        test_helpers.compare_strings(str(t), f'Teller: 1 Total service time: {expected}')
    for x in range(0,100,10):
        t.accept(10)
        assert not t.is_available(), f'Teller should not be available after accepting 10 units of work on the {x} iteration'
        expected_service_time(x)
        t.service(5)
        expected_service_time(x+5)
        assert not t.is_available(), f'Teller should not be available after completing only 5 of 10 available unit work on the {x} iteration'
        t.service(5)
        expected_service_time(x+10)
        assert t.is_available(), f'Teller should be available after completing 10 unit work on the {x} iteration'
        t.service(5)
        expected_service_time(x+10)
        assert t.is_available(), f'Teller should be available after completing 10 unit work on the {x} iteration'
#test_teller_accept_and_run_incomplete(banking, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Teller can be made available properly")
def test_teller_accept_and_run_make_available(banking, test_helpers):
    teller_name = 1
    t = banking.Teller(name=teller_name)
    def expected_service_time(expected):
        assert (ans:=t.get_total_service_time()) == expected, f'Service time should have been: {expected}, but was {ans}'
        test_helpers.compare_strings(str(t), f'Teller: 1 Total service time: {expected}')
    for x in range(0,10,1):
        t.accept(10)
        assert not t.is_available(), f'Teller should not be available after accepting 10 units of work on the {x} iteration'
        t.service(1)
        expected_service_time(x+1)
        t.make_available()
        t.service(5)
        expected_service_time(x+1)
#test_teller_accept_and_run_make_available(banking, test_helpers)
