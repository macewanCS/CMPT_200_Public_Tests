from otter.test_files import test_case

OK_FORMAT = False

name = "init-tests"
points = None

@test_case(points=1, hidden=False, 
    success_message="Table Methods Defined!")
def verify_methods(table, test_helpers):
    t = table.Table() 
    assert t is not None, 'Time not correctly defined or not currently imported'
    test_helpers.methods_check(t, {'__init__', 
                                   '__str__', '__len__', 'add', 'get', 'remove', 'keys', 'load', '_show_entries'})
    try: 
        table.Table(capacity=10)
    except:
        assert False, 'Unable to create table with a set capacity'
   
#verify_methods(table, test_helpers)
@test_case(points=10, hidden=False, 
    success_message="Hey, Good Job, this looks like it could be an actual hashtable!")
def check_sets_dicts_lists(test_helpers):
    bad_lines = test_helpers.uses_dicts_or_sets_or_lists ('table.py')
    assert bad_lines == set(), f"It seems you've used a dictionary, set or list at in one or more lines: {bad_lines} to get these marks you have to do without!"
   
#check_sets_dicts_lists(test_helpers)
@test_case(points=10, hidden=False, 
    success_message="Empty table seems to work as expected!")
def check_empty(table, test_helpers):
    t = table.Table()
    assert 0 == len(t), f'Table len initially not 0, is instead {len(t)}'
    assert len(list(t.keys())) == 0, f"Len of table keys should be 0, is instead {len(list(t.keys()))}"
    test_helpers.compare_strings('{}', str(t))
    assert t.load() == 0, f'The load factor of an empty table should be 0, yours is {t.load()}'
    test_helpers.assert_raises(lambda: t.get('a key'), KeyError, 'Getting "a key" on an empty table should raise a KeyError')
    test_helpers.assert_raises(lambda: t.remove('a key'), KeyError, 'Removing "a key" on an empty table should raise a KeyError')
#check_empty(table, test_helpers)
@test_case(points=7, hidden=False, 
    success_message="Table str method seems to match expectations")
def check_str(table, test_helpers):
    t = table.Table()
    t.add('hello', 'world')
    test_helpers.compare_strings("{'hello':'world'}", str(t), "If you are having difficulties with the quotes expected around str values, you can call the __repr__ method on your key/value to get python to handle this for you!")
    t = table.Table()
    t.add(1,2)
    test_helpers.compare_strings("{1:2}", str(t), "These are integers, and should not be surrounded by quotes. Have a look at calling the __repr__ method you your keys/values ")
    t.add(3,4)
    t.add(5,"hi")
    assert '3:4' in str(t), "It seems your output is missing the key value pair of 3:4"
   # assert "5:'hi'" in str(t), "It seems your output is missing the key value pair of 5:'hi'"
    assert str(t).count(',') == 2, "Your output should have 2 commas in it"
    options = "{5:'hi', 3:4, 1:2}", "{5:'hi', 1:2, 3:4}", "{3:4, 1:2, 5:'hi'}", "{3:4, 5:'hi', 1:2}","{1:2, 3:4, 5:'hi'}", "{1:2, 5:'hi', 3:4}"
    assert str(t) in (options), f'Your str "{str(t)}" is not one of the acceptable options: {options}'
    
#check_str(table, test_helpers)
@test_case(points=5, hidden=False, 
    success_message="The add and get methods seem to work without re-hashing or deletion")
def check_add(table, test_helpers):
    t = table.Table(10)
    counter = 1
    load_factors = []
    for key in [1, 2, 3, 4, 5]:
        t.add(key, counter)
        t.add(key, counter)  # make sure it doesn't insert multiple entries
        assert counter == len(t), f"Expected length of the table to be {counter}, but instead was {len(t)}"
        assert key in t.keys(), f"The key '{key}' should be in the table"
        assert t.load() < 2/3, f"The load factor should be less than 2/3, yours is reported as {t.load()}"
        if len(load_factors)>0:
            assert t.load() > load_factors[-1], "Load factor should be increasing, yours does not seem to"
        load_factors.append(t.load())
        assert t.get(key) == counter, f"The key: '{key}' did not return '{counter}', instead got '{t.get(key)}'"
        counter += 1
  
#check_add(table, test_helpers)
@test_case(points=10, hidden=False, 
    success_message="The add and get methods seem to work when rehashing without deletion")
def check_add_rehash(table, test_helpers):
    t = table.Table(2)
    counter = 1
    load_records = set()
    for key in [1, 2, 3, 4, 5]:
        load_records.add(t.load())
        t.add(key, counter)
        t.add(key, counter)  # make sure it doesn't insert multiple entries
        assert counter == len(t), f"Expected length of the table to be {counter}, but instead was {len(t)}"
        assert key in t.keys(), f"The key '{key}' should be in the table"
        assert t.load() < 2/3, f"The load factor should be less than 2/3, yours is reported as {t.load()}"
        if key == 2:
            assert t.load() < max(load_records), 'You should have re-hashed the table before the second addition, the load factor should be lower than it was last time'
        assert t.get(key) == counter, f"The key: '{key}' did not return {counter}, instead got {t.get(key).__repr__()}" 
        counter += 1  
#check_add_rehash(table, test_helpers)
@test_case(points=10, hidden=False, 
    success_message="The add and get methods seem to work with deletion")
def check_add_delete(table, test_helpers):
    t = table.Table(10)
    counter = 1
    load_factors = []
    for key, length in {1:1, 2:2, 3:2, 4:3, 5:3}.items():
        t.add(key, counter)
        t.add(key, counter)  # make sure it doesn't insert multiple entries
        assert length == len(t), f"Expected length of the table to be {length}, but instead was {len(t)}"
        assert key in t.keys(), f"The key '{key}' should be in the table"
        assert t.load() < 2/3, f"The load factor should be less than 2/3, yours is reported as {t.load()}"
        if len(load_factors)>0:
            if key not in (3,5):
                assert t.load() > load_factors[-1], "Load factor should be increasing when we add new things, yours does not seem to"
            else:
                assert t.load() == load_factors[-1], f"Load factor was expected to be {load_factors[-1]} but was {t.load()}, make sure that you adjust your load factor after deletion"
        load_factors.append(t.load())
        assert t.get(key) == counter, f"The key: '{key}' did not return '{counter}', instead got '{t.get(key)}'" 
        counter += 1
        if key in (2, 4):
            old_load = t.load()
            old_len = len(t)
            t.remove(key)
            assert old_load > t.load(), 'your load factor should decrease after a deletion, yours did not'
            assert old_len >= len(t), 'your len should decrease after a deletion, yours did not'
            
  
#check_add_delete(table, test_helpers)
@test_case(points=10, hidden=False, 
    success_message="The add and get methods seem to work with deletion AND rehashing")
def check_add_delete_rehash(table, test_helpers):
    t = table.Table(2)
    counter = 1
    load_factors = []
    for key, length in {1:1, 2:2, 3:2, 4:3, 5:3}.items():
        t.add(key, counter)
        t.add(key, counter)  # make sure it doesn't insert multiple entries
        assert length == len(t), f"Expected length of the table to be {length}, but instead was {len(t)}"
        assert key in t.keys(), f"The key '{key}' should be in the table"
        assert t.load() < 2/3, f"The load factor should be less than 2/3, yours is reported as {t.load()}"
        load_factors.append(t.load())
        assert t.get(key) == counter, f"The key: '{key}' did not return '{counter}', instead got '{t.get(key)}'" 
        counter += 1
        if key in (2, 4):
            old_load = t.load()
            old_len = len(t)
            t.remove(key)
            assert old_load > t.load(), 'your load factor should decrease after a deletion, yours did not'
            assert old_len >= len(t), 'your len should decrease after a deletion, yours did not'
            
  
#check_add_delete_rehash(table, test_helpers)
@test_case(points=25, hidden=False, 
    success_message="The big test was a success, your output mostly matches a python dict, good work!")

def big_test(table, test_helpers):
    import random
    random.seed(42)
    t = table.Table(2)
    d = {}
    for i in range(500):
        key = random.randint(1, 1_000_000)
        value = random.randint(1, 1_000_000)
        d[key] = value
        t.add(key, value)
        if random.randint(0,1):
            prior_len = len(t)
            prior_load = t.load()
            d.pop(key)
            t.remove(key)
            assert prior_len > len(t)
            assert prior_load > t.load()
        for k, v in d.items():
            assert t.get(k) == v, f'You returned the wrong value: {t.get(k)} for key: {k} I was expecting {v}'
        
  
#big_test(table, test_helpers)
