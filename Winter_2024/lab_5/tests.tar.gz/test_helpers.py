import difflib
import sys
import operator

ENDC = "\033[0m"
DELETEC = "\033[1m\033[91m"
ADDC = "\033[1m\033[92m"


def compare_strings(expected, got):
    if got == expected:
        return
    got = repr(got)
    expected = repr(expected)
    message = f"""The test expected:
{expected}

Your output was:
{got}

"""
    results = difflib.ndiff(got, expected)
    result = ""
    for i, s in enumerate(results):
        if s[0] == " ":
            result += s[-1]
            continue

        # there is an error
        if s[0] == "-":
            result += DELETEC
            message += f"Delete {s[-1]} from position {i}\n"
        elif s[0] == "+":
            result += ADDC
            message += f"Add {s[-1]} to position {i}\n"
        result += s[-1].replace(" ", "_")
        result += ENDC

    print(
        DELETEC
        + "red "
        + ENDC
        + "characters need to be deleted "
        + ADDC
        + "green"
        + ENDC
        + " characters need to be added. Note that spaces that are missing are replaced with UNDERSCORES '_' so that they may be highlighted):",
        file=sys.stderr,
    )
    print("", file=sys.stderr)
    print(result, file=sys.stderr)
    print("", file=sys.stderr)
    print("", file=sys.stderr)

    assert got == expected, "Sorry your output is not correct"


def methods_check(inbound_object, expected_methods={}):
    missing_methods = set()
    for method in expected_methods:
        if method not in dir(inbound_object):
            missing_methods.add(method)
    if len(missing_methods) > 0:
        raise AssertionError(
            f"The following methods are not yet implemented: {', '.join(missing_methods)}"
        )


operators = {
    "+": operator.add,
    "-": operator.sub,
    "<": operator.lt,
    ">": operator.gt,
    ">=": operator.ge,
    "<=": operator.le,
    "==": operator.eq,
    "!=": operator.ne,
}


def expected(a, b, operand, negate=False):
    if negate:
        assert not operators[operand](a, b), f"Expected NOT {a} {operand}, {b}"
    else:
        assert operators[operand](a, b), f"Expected {a} {operand}, {b}"


def compare_unequal(smaller, bigger):
    expected(smaller, bigger, "<")
    expected(smaller, bigger, "<=")
    expected(bigger, smaller, ">=")
    expected(bigger, smaller, ">")
    expected(bigger, smaller, "!=")
    expected(smaller, bigger, ">", negate=True)
    expected(smaller, bigger, ">=", negate=True)
    expected(bigger, smaller, "<=", negate=True)
    expected(bigger, smaller, "<", negate=True)
    expected(bigger, smaller, "==", negate=True)


def compare_equal(a, b):
    expected(a, b, "==")
    expected(a, b, "!=", negate=True)
    expected(a, b, ">=")
    expected(a, b, "<=")
    expected(b, a, "==")
    expected(b, a, "!=", negate=True)
    expected(b, a, ">=")
    expected(b, a, "<=")
    expected(b, a, ">", negate=True)
    expected(b, a, "<", negate=True)


def expect_disjoint(a, b, negate=False):
    if negate:
        assert not a.disjoint(b), f"expected {a} not to be disjoint from {b}"
        assert not b.disjoint(a), f"expected {b} not to be disjoint from {a}"
    else:
        assert a.disjoint(b), f"expected {a} to be disjoint from {b}"
        assert b.disjoint(a), f"expected {b} to be disjoint from {a}"


def expect_contains(a, b, negate=False):
    if not negate:
        assert a.contains(b), f"expected {a} to contain {b}"
    else:
        assert not a.contains(b), f"d {a} not to contain {b}"
