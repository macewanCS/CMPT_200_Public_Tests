from otter.test_files import test_case

OK_FORMAT = False

name = "Methods Exist"
points = None

@test_case(points=1, hidden=False, 
    success_message="Required Scheduler methods exist")
def verify_methods(exam_scheduler, test_helpers):
    x = exam_scheduler.Schedule('exam_times_1.csv', 'room_avail_1.csv')
    assert x is not None, 'Schedule not correctly defined or not currently imported'
    test_helpers.methods_check(x,{'__init__', 
                                   '__str__'})
#verify_methods(exam_scheduler, test_helpers)
