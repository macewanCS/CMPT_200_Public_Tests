from otter.test_files import test_case

OK_FORMAT = False

name = "Room-avail-2"
points = None

@test_case(points=1, hidden=False, 
    success_message="room_avail_2.csv and exam_times_1.csv correctly scheduled")
def verify_room_2_exams_1(exam_scheduler, test_helpers):
    exam = 1
    room = 2
    test_helpers.compare_strings('No schedule is possible for exams in exam_times_1.csv using room availability in room_avail_2.csv',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=3, hidden=False, 
    success_message="room_avail_2.csv and exam_times_2.csv correctly scheduled")
def verify_room_2_exams_2(exam_scheduler, test_helpers):
    exam = 2
    room = 2
    test_helpers.compare_strings('Room 6-245: 09:10 - 15:30 :\n\tCMPT 103: 12:10 - 14:30\n\nRoom 7-245: 08:20 - 16:50 :\n\tCMPT 200: 09:00 - 11:00\n\tCMPT 101: 11:10 - 14:20\n\nRoom 5-173: 09:10 - 21:00 :\n\tCMPT 201: 09:10 - 12:50\n',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=3, hidden=False, 
    success_message="room_avail_2.csv and exam_times_3.csv correctly scheduled")
def verify_room_2_exams_3(exam_scheduler, test_helpers):
    exam = 3
    room = 2
    test_helpers.compare_strings('Room 6-245: 09:10 - 15:30 :\n\tCMPT 204: 14:30 - 15:30\n\tCMPT 101: 11:10 - 14:30\n\nRoom 5-173: 09:10 - 21:00 :\n\tCMPT 103: 11:00 - 17:00\n\tCMPT 200: 17:00 - 18:30\n\tCMPT 201: 18:30 - 20:40\n',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=1, hidden=False, 
    success_message="room_avail_2.csv and exam_times_4.csv correctly scheduled")
def verify_room_2_exams_4(exam_scheduler, test_helpers):
    exam = 4
    room = 2
    test_helpers.compare_strings('No schedule is possible for exams in exam_times_4.csv using room availability in room_avail_2.csv',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=1, hidden=False, 
    success_message="room_avail_2.csv and exam_times_5.csv correctly scheduled")
def verify_room_2_exams_5(exam_scheduler, test_helpers):
    exam = 5
    room = 2
    test_helpers.compare_strings('No schedule is possible for exams in exam_times_5.csv using room availability in room_avail_2.csv',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
