from otter.test_files import test_case

OK_FORMAT = False

name = "Time"
points = None

@test_case(points=1, hidden=False, 
    success_message="Time Methods Defined!")
def verify_methods(exam_scheduler, test_helpers):
    t = exam_scheduler.Time('00:00') 
    assert t is not None, 'Time not correctly defined or not currently imported'
    test_helpers.methods_check(t, {'__init__', 
                                   '__str__', '__eq__', '__gt__', '__ge__', '__lt__', '__eq__', '__ne__'})
verify_methods(exam_scheduler, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Time string is correct")
def verify_time_string(exam_scheduler, test_helpers):
    for h in range(24):
        for m in range(60):
            t = exam_scheduler.Time(f'{h}:{m}')
            test_helpers.compare_strings(f'{h:02d}:{m:02d}', str(t)) 
verify_time_string(exam_scheduler, test_helpers)
@test_case(points=1, hidden=False, 
    success_message="Time raises errors when it should")
def verify_time_errors(exam_scheduler, test_helpers):
    for h in range(24,25):
        for time in (f'{h}:0', f'{23-h}:0'):
            try:
                t = exam_scheduler.Time(time)
                raise AssertionError(f'Code did not raise a value error for time {time}')
            except ValueError as e:
                test_helpers.compare_strings(f"Time entered '{time}' is not a valid time", str(e))
        for m in range(60,106,5):
            for time in (f'12:{m}', f'12:{59-m}'):
                try:
                    t = exam_scheduler.Time(time)
                    raise AssertionError(f'Code did not raise a value error for time {time}')
                except ValueError as e:
                    test_helpers.compare_strings(f"Time entered '{time}' is not a valid time", str(e))
        
verify_time_errors(exam_scheduler, test_helpers)
@test_case(points=4, hidden=False, 
    success_message="Time comparisons are correct")
def verify_time_comparisons(exam_scheduler, test_helpers):
    import random
    random.seed(1)
    for x in range(1000):
        h1 = random.randint(0,23)
        h2 = random.randint(0,23)
        m1 = random.randint(0,59)
        m2 = random.randint(0,59)
        t1 = exam_scheduler.Time(f"{h1}:01")
        t2 = exam_scheduler.Time(f"{h2}:01")
        t3 = exam_scheduler.Time(f"12:{m1}")
        t4 = exam_scheduler.Time(f"12:{m2}")
        t5 = exam_scheduler.Time(f"{h1}:{m1}")
        t6 = exam_scheduler.Time(f"{h2}:{m2}")
        if h1 == h2:
            test_helpers.compare_equal(t1,t2)
        elif h1 < h2:
            test_helpers.compare_unequal(t1,t2)
            test_helpers.compare_unequal(t5,t6)
        elif h1 > h2:
            test_helpers.compare_unequal(t2,t1)
            test_helpers.compare_unequal(t6,t5)
        if m1 == m2:
            test_helpers.compare_equal(t3,t4)
        elif m1 < m2:
            test_helpers.compare_unequal(t3,t4)
        elif m1 > m2:
            test_helpers.compare_unequal(t4,t3) 
        if h1 == h2 and m1 == m2:
            test_helpers.compare_equal(t5, t6)
    t1 = exam_scheduler.Time(f"13:58")
    t2 = exam_scheduler.Time(f"13:58")
    assert t1 == t2, f'Expected {t1} == {t2}'

verify_time_comparisons(exam_scheduler, test_helpers)
