from otter.test_files import test_case

OK_FORMAT = False

name = "Room-avail-4"
points = None

@test_case(points=3, hidden=False, 
    success_message="room_avail_4.csv and exam_times_1.csv correctly scheduled")
def verify_room_4_exams_1(exam_scheduler, test_helpers):
    exam = 1
    room = 4
    test_helpers.compare_strings('Room 9-400: 05:20 - 14:30 :\n\tCMPT 305: 05:30 - 12:10\n\nRoom 5-172: 08:00 - 20:00 :\n\tCMPT 103: 12:00 - 14:10\n\nRoom 5-173: 09:10 - 21:10 :\n\tCMPT 204: 12:00 - 14:00\n',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=3, hidden=False, 
    success_message="room_avail_4.csv and exam_times_2.csv correctly scheduled")
def verify_room_4_exams_2(exam_scheduler, test_helpers):
    exam = 2
    room = 4
    test_helpers.compare_strings('Room 9-400: 05:20 - 14:30 :\n\tCMPT 103: 12:10 - 14:30\n\tCMPT 200: 09:00 - 11:00\n\nRoom 5-172: 08:00 - 20:00 :\n\tCMPT 201: 09:10 - 12:50\n\nRoom 5-173: 09:10 - 21:10 :\n\tCMPT 101: 11:10 - 14:20\n',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=3, hidden=False, 
    success_message="room_avail_4.csv and exam_times_3.csv correctly scheduled")
def verify_room_4_exams_3(exam_scheduler, test_helpers):
    exam = 3
    room = 4
    test_helpers.compare_strings('Room 9-400: 05:20 - 14:30 :\n\tCMPT 101: 11:10 - 14:30\n\nRoom 5-172: 08:00 - 20:00 :\n\tCMPT 204: 14:30 - 15:30\n\tCMPT 200: 17:00 - 18:30\n\nRoom 5-173: 09:10 - 21:10 :\n\tCMPT 103: 11:00 - 17:00\n\tCMPT 201: 18:30 - 20:40\n',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=1, hidden=False, 
    success_message="room_avail_4.csv and exam_times_4.csv correctly scheduled")
def verify_room_4_exams_4(exam_scheduler, test_helpers):
    exam = 4
    room = 4
    test_helpers.compare_strings('No schedule is possible for exams in exam_times_4.csv using room availability in room_avail_4.csv',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=1, hidden=False, 
    success_message="room_avail_4.csv and exam_times_5.csv correctly scheduled")
def verify_room_4_exams_5(exam_scheduler, test_helpers):
    exam = 5
    room = 4
    test_helpers.compare_strings('No schedule is possible for exams in exam_times_5.csv using room availability in room_avail_4.csv',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
