from otter.test_files import test_case

OK_FORMAT = False

name = "Room-avail-1"
points = None

@test_case(points=1, hidden=False, 
    success_message="room_avail_1.csv and exam_times_1.csv correctly scheduled")
def verify_room_1_exams_1(exam_scheduler, test_helpers):
    exam = 1
    room = 1
    test_helpers.compare_strings('No schedule is possible for exams in exam_times_1.csv using room availability in room_avail_1.csv',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=1, hidden=False, 
    success_message="room_avail_1.csv and exam_times_2.csv correctly scheduled")
def verify_room_1_exams_2(exam_scheduler, test_helpers):
    exam = 2
    room = 1
    test_helpers.compare_strings('No schedule is possible for exams in exam_times_2.csv using room availability in room_avail_1.csv',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=1, hidden=False, 
    success_message="room_avail_1.csv and exam_times_3.csv correctly scheduled")
def verify_room_1_exams_3(exam_scheduler, test_helpers):
    exam = 3
    room = 1
    test_helpers.compare_strings('No schedule is possible for exams in exam_times_3.csv using room availability in room_avail_1.csv',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=1, hidden=False, 
    success_message="room_avail_1.csv and exam_times_4.csv correctly scheduled")
def verify_room_1_exams_4(exam_scheduler, test_helpers):
    exam = 4
    room = 1
    test_helpers.compare_strings('No schedule is possible for exams in exam_times_4.csv using room availability in room_avail_1.csv',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=1, hidden=False, 
    success_message="room_avail_1.csv and exam_times_5.csv correctly scheduled")
def verify_room_1_exams_5(exam_scheduler, test_helpers):
    exam = 5
    room = 1
    test_helpers.compare_strings('No schedule is possible for exams in exam_times_5.csv using room availability in room_avail_1.csv',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
