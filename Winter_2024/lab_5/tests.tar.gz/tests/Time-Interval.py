from otter.test_files import test_case

OK_FORMAT = False

name = "Time-Interval"
points = None

@test_case(points=1, hidden=False, 
    success_message="Time Interval Methods Defined!")
def verify_methods(exam_scheduler, test_helpers):
    t = exam_scheduler.TimeInterval('00:00', '12:00') 
    assert t is not None, 'Time not correctly defined or not currently imported'
    test_helpers.methods_check(t, {'__init__', '__str__', '__repr__', 'contains', 'disjoint'})
#verify_methods(exam_scheduler, test_helpers)
@test_case(points=2, hidden=False, 
    success_message="TimeInterval str format appears correct")
def verify_interval_string(exam_scheduler, test_helpers):
            t = exam_scheduler.TimeInterval('12:00', '12:55')
            test_helpers.compare_strings(f"12:00 - 12:55", str(t))
   
#verify_interval_string(exam_scheduler, test_helpers)
@test_case(points=2, hidden=False, 
    success_message="TimeInterval raises errors when it should")
def verify_interval_errors(exam_scheduler, test_helpers):
            try:
                t = exam_scheduler.TimeInterval('12:00', '2:55')
                raise AssertionError(f'Code did not raise a value error for a negative time interval')
            except ValueError as e:
                test_helpers.compare_strings(f"Negative time interval detected", str(e))
            try:
                t = exam_scheduler.TimeInterval('9:55', '9:55')
                raise AssertionError(f'Code did not raise a value error for a zero length time interval')
            except ValueError as e:
                test_helpers.compare_strings(f"Zero length time interval detected", str(e))
   
#verify_interval_errors(exam_scheduler, test_helpers)
@test_case(points=2, hidden=False, 
    success_message="Disjoint seems to work!")
def verify_disjoint(exam_scheduler, test_helpers):
    is_disjoint = ((("00:00", "12:00"),("12:01", "13:00")),
                   (("2:00", "12:00"),("12:59", "13:00")),
                   (("00:01", "00:02"),("12:01", "13:00")),
                   (("00:00", "12:00"),("12:00", "13:00")))
    for i in is_disjoint:
        t1, t2 = map(lambda x: exam_scheduler.TimeInterval(*x), i)
        test_helpers.expect_disjoint(t1,t2)
    is_NOT_disjoint = ((("00:00", "12:00"),("11:59", "13:00")),
           (("12:00", "14:00"),("12:59", "14:01")),
           (("00:01", "00:02"),("00:01", "00:04")),
           (("04:00", "12:00"),("00:00", "13:00")))
    for i in is_NOT_disjoint:
        t1, t2 = map(lambda x: exam_scheduler.TimeInterval(*x), i)
        test_helpers.expect_disjoint(t1,t2,True)
#verify_disjoint(exam_scheduler, test_helpers)
@test_case(points=2, hidden=False, 
    success_message="Contains seems to work!")
def verify_contains(exam_scheduler, test_helpers):
    contains = ((("00:00", "12:00"),("1:00", "10:00")),
                   (("2:00", "12:00"),("11:58", "11:59")),
                   (("00:01", "00:03"),("0:01", "0:02")),
                   (("00:00", "23:59"),("00:00", "23:58")))
    for i in contains:
        t1, t2 = map(lambda x: exam_scheduler.TimeInterval(*x), i)
        test_helpers.expect_contains(t1,t2)
        test_helpers.expect_contains(t2,t1,True)
    not_contains = ((("00:00", "12:00"),("13:00", "14:00")),
                   (("2:00", "12:00"),("12:00", "12:01")),
                   (("00:01", "00:03"),("0:00", "0:01")),
                   (("00:00", "23:58"),("00:01", "23:59")))
    for i in not_contains:
        t1, t2 = map(lambda x: exam_scheduler.TimeInterval(*x), i)
        test_helpers.expect_contains(t1,t2,True)
        test_helpers.expect_contains(t2,t1,True)
    symmetric_contains = ((("00:00", "12:00"),("00:00", "12:00")),
                   (("12:00", "12:01"),("12:00", "12:01")),
                   (("00:01", "00:03"),("0:01", "0:03")),
                   (("00:01", "23:59"),("00:01", "23:59")))
    for i in symmetric_contains:
        t1, t2 = map(lambda x: exam_scheduler.TimeInterval(*x), i)
        test_helpers.expect_contains(t1,t2)
        test_helpers.expect_contains(t2,t1)
#verify_contains(exam_scheduler, test_helpers)
