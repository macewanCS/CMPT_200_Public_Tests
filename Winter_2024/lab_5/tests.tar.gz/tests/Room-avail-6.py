from otter.test_files import test_case

OK_FORMAT = False

name = "Room-avail-6"
points = None

@test_case(points=1, hidden=False, 
    success_message="room_avail_6.csv and exam_times_1.csv correctly scheduled")
def verify_room_6_exams_1(exam_scheduler, test_helpers):
    exam = 1
    room = 6
    test_helpers.compare_strings('No schedule is possible for exams in exam_times_1.csv using room availability in room_avail_6.csv',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=3, hidden=False, 
    success_message="room_avail_6.csv and exam_times_2.csv correctly scheduled")
def verify_room_6_exams_2(exam_scheduler, test_helpers):
    exam = 2
    room = 6
    test_helpers.compare_strings('Room 5-173: 09:10 - 21:50 :\n\tCMPT 103: 12:10 - 14:30\n\nRoom 6-385: 05:05 - 11:25 :\n\tCMPT 200: 09:00 - 11:00\n\nRoom 8-340: 08:00 - 14:30 :\n\tCMPT 201: 09:10 - 12:50\n\nRoom 7-385: 09:00 - 16:50 :\n\tCMPT 101: 11:10 - 14:20\n',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=3, hidden=False, 
    success_message="room_avail_6.csv and exam_times_3.csv correctly scheduled")
def verify_room_6_exams_3(exam_scheduler, test_helpers):
    exam = 3
    room = 6
    test_helpers.compare_strings('Room 5-173: 09:10 - 21:50 :\n\tCMPT 103: 11:00 - 17:00\n\tCMPT 200: 17:00 - 18:30\n\tCMPT 201: 18:30 - 20:40\n\nRoom 7-340: 12:00 - 17:00 :\n\tCMPT 204: 14:30 - 15:30\n\nRoom 8-340: 08:00 - 14:30 :\n\tCMPT 101: 11:10 - 14:30\n',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=3, hidden=False, 
    success_message="room_avail_6.csv and exam_times_4.csv correctly scheduled")
def verify_room_6_exams_4(exam_scheduler, test_helpers):
    exam = 4
    room = 6
    test_helpers.compare_strings('Room 5-173: 09:10 - 21:50 :\n\tCMPT 340: 13:10 - 16:20\n\tCMPT 204: 11:00 - 13:10\n\nRoom 6-385: 05:05 - 11:25 :\n\tCMPT 305: 05:10 - 11:20\n\nRoom 5-172: 08:00 - 12:10 :\n\tCMPT 320: 08:00 - 12:00\n\nRoom 7-340: 12:00 - 17:00 :\n\tCMPT 103: 12:10 - 14:30\n\nRoom 8-340: 08:00 - 14:30 :\n\tCMPT 101: 11:20 - 14:30\n\tCMPT 200: 09:00 - 11:20\n\nRoom 7-385: 09:00 - 16:50 :\n\tCMPT 201: 09:00 - 12:00\n',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
@test_case(points=3, hidden=False, 
    success_message="room_avail_6.csv and exam_times_5.csv correctly scheduled")
def verify_room_6_exams_5(exam_scheduler, test_helpers):
    exam = 5
    room = 6
    test_helpers.compare_strings('Room 5-173: 09:10 - 21:50 :\n\tCMPT 201: 09:30 - 12:00\n\nRoom 5-172: 08:00 - 12:10 :\n\tCMPT 200: 08:30 - 11:50\n\nRoom 8-340: 08:00 - 14:30 :\n\tCMPT 320: 08:00 - 12:30\n\nRoom 7-385: 09:00 - 16:50 :\n\tCMPT 204: 11:10 - 13:20\n',
                                  str(exam_scheduler.Schedule(f'exam_times_{exam}.csv', f'room_avail_{room}.csv')))
